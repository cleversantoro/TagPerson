#!/usr/bin/python
#-*- coding:utf-8 -*-

from data import *
from os import path
import xml.dom.minidom as minidom
from gtk import gdk

def load_racas(filename='racas.xml'):
	doc = minidom.parse(filename)

	racas = {}
	for node in doc.childNodes[0].getElementsByTagName('raca'):
		raca = Raca(node.getAttribute('nome').encode('utf-8'))
		imagem_file = path.join(path.split(filename)[0],
										node.getAttribute('imagem'))

		if path.isfile(imagem_file):
			try:
				raca.imagem = gdk.pixbuf_new_from_file(imagem_file)
			except:
				pass

		node_desc = node.getElementsByTagName('descricao')
		raca.descricao = node_desc[0].childNodes[0].nodeValue.encode('utf-8').strip()
		raca.velocidade_base = int(node.getElementsByTagName('velocidadeBase')[0].\
								getAttribute('valor'))
		raca.ef = int(node.getElementsByTagName('EF')[0].getAttribute('valor'))
		raca.altura = int(node.getElementsByTagName('altura')[0].\
								getAttribute('valor'))
		raca.peso = int(node.getElementsByTagName('peso')[0].\
								getAttribute('valor'))
		idade = node.getElementsByTagName('idade')[0]
		raca.idade = (int(idade.getAttribute('min')),
							int(idade.getAttribute('max')))
							
		node_indisp = node.getElementsByTagName('profissoesIndisponiveis')
		if node_indisp:
			for indisp in node_indisp[0].getElementsByTagName('profissao'):
				raca.profissoes_indisponiveis.append(indisp.getAttribute('nome').\
																encode('utf-8'))

		node_bonus = node.getElementsByTagName('bonusAtributos')
		if node_bonus:
			for bonus in node_bonus[0].childNodes:
				if bonus.nodeType == bonus.ELEMENT_NODE:
					raca.set_bonus_atributo(bonus.nodeName,
													int(bonus.getAttribute('valor')))

		racas[raca.name] = raca

	return racas
	

def load_profissoes(filename='profissoes.xml'):
	doc = minidom.parse(filename)

	profissoes = {}
	for node in doc.childNodes[0].getElementsByTagName('profissao'):
		prof = Profissao(node.getAttribute('nome').encode('utf-8'))

		magia = node.getAttribute('atributoParaMagia').encode('utf-8')
		if magia == 'Intelecto':
			prof.atributo_para_magia = Base.INT
		elif magia == 'Carisma':
			prof.atributo_para_magia = Base.CAR
		elif magia == 'Percepção':
			prof.atributo_para_magia = Base.PER

		node_desc = node.getElementsByTagName('descricao')
		prof.descricao = node_desc[0].childNodes[0].nodeValue.encode('utf-8').strip()

		prof.eh = int(node.getElementsByTagName('EH')[0].getAttribute('valor'))
		prof.pontos_armas = int(node.getElementsByTagName('pontosArmas')[0].\
									getAttribute('valor'))
		prof.pontos_combate = int(node.getElementsByTagName('pontosCombate')[0].\
									getAttribute('valor'))

		posses = node.getElementsByTagName('posses')[0]
		prof.posses = [int(posses.getAttribute('ouro')),
							int(posses.getAttribute('prata')),
							int(posses.getAttribute('cobre'))]

		habilidades = node.getElementsByTagName('habilidades')[0]
		prof.pontos_habilidades = int(habilidades.getAttribute('pontos'))
		prof.grupo_habilidade_penalizado = habilidades.\
										getAttribute('grupoPenalizado').encode('utf-8')
		prof.especializacoes_habilidade = habilidades.\
										getAttribute('especializacoes').encode('utf-8').\
										split(',')

		node_equip = node.getElementsByTagName('equipamento')[0].\
											getElementsByTagName('item')
		for item in node_equip:
			prof.equipamento.append(item.getAttribute('nome').encode('utf-8'))

		profissoes[prof.name] = prof

	return profissoes


def load_panteao(filename='panteao.xml'):
	doc = minidom.parse(filename)

	panteao = {}
	for node in doc.childNodes[0].getElementsByTagName('deus'):
		deus = node.getAttribute('nome').encode('utf-8')
		esfera = node.getAttribute('esfera').encode('utf-8')
		node_desc = node.getElementsByTagName('descricao')
		descricao = node_desc[0].childNodes[0].nodeValue.encode('utf-8').strip()
		
		panteao[deus] = (esfera, descricao)

	return panteao

def load_grimoire(filename='grimoire.xml'):
	doc = minidom.parse(filename)

	magias = []
	for node in doc.childNodes[0].getElementsByTagName('magia'):
		magia = Spell(node.getAttribute('nome').encode('utf-8'))
		magia.evocacao = node.getElementsByTagName('evocacao')[0].\
								getAttribute('tipo').encode('utf-8')
		magia.alcance = node.getElementsByTagName('alcance')[0].\
								getAttribute('tipo').encode('utf-8')
		magia.duracao = node.getElementsByTagName('duracao')[0].\
								getAttribute('valor').encode('utf-8')
		
		node_desc = node.getElementsByTagName('descricao')
		magia.descricao = node_desc[0].\
								childNodes[0].nodeValue.encode('utf-8').strip()
		
		node_efeitos = node.getElementsByTagName('efeitos')[0].\
											getElementsByTagName('efeito')
		for efeito in node_efeitos:
			magia.efeitos[int(efeito.getAttribute('nivel'))] = efeito.\
									childNodes[0].nodeValue.encode('utf-8').strip()
									
		magias.append(magia)

	return magias

def load_habilidades(filename='habilidades.xml'):
	doc = minidom.parse(filename)
	
	habilidades = {}
	for element in doc.childNodes[0].childNodes:
		if element.nodeType == element.ELEMENT_NODE and \
			element.nodeName == 'grupo':
			grupo = element.getAttribute('nome').encode('utf-8')
			habilidades[grupo] = []
			for node in element.getElementsByTagName('habilidade'):
				habil = Skill(node.getAttribute('nome').encode('utf-8'), grupo)
								
				habil.precisaNivel = node.getAttribute('precisaNivel') == 'sim'
				habil.restrita = node.getAttribute('restrita') == 'sim'
				habil.especializacao = node.getAttribute('especializacao') == 'sim'

				node_desc = node.getElementsByTagName('descricao')
				habil.descricao = node_desc[0].childNodes[0].nodeValue.\
										encode('utf-8').strip()

				node_dific = node.getElementsByTagName('dificuldades')[0].\
											getElementsByTagName('dificuldade')
				for dific in node_dific:
					habil.dificuldades[dific.getAttribute('nivel').encode('utf-8')] = \
						dific.childNodes[0].nodeValue.encode('utf-8').strip()

				habilidades[grupo].append(habil)
				
	
	return habilidades

def load_equipamento(filename='equipamento.xml'):
	doc = minidom.parse(filename)
	
	equipamento = []
	for node in doc.childNodes[0].getElementsByTagName('item'):
		name = node.getAttribute('nome').encode('utf-8')
		tipo = node.getAttribute('tipo').encode('utf-8')
		if tipo == 'Arma':
			item = Arma(name)
		elif tipo == 'Armadura':
			item = Armadura(name)
		elif tipo == 'Escudo':
			item = Escudo(name)
		elif tipo == 'Elmo':
			item = Defesa(name)
		else:
			item = Item(name, tipo)
		
		# Preco
		ouro, prata, cobre = 0, 0, 0
		preco = node.getElementsByTagName('preco')[0]
		moedas = preco.getAttribute('ouro')
		if moedas:
			ouro = int(moedas)
		moedas = preco.getAttribute('prata')
		if moedas:
			prata = int(moedas)
		moedas = preco.getAttribute('cobre')
		if moedas:
			cobre = int(moedas)

		item.set_preco(ouro, prata, cobre)

		node_desc = node.getElementsByTagName('descricao')
		if node_desc:
			item.descricao = node_desc[0].childNodes[0].\
									nodeValue.encode('utf-8').strip()

		node_def = node.getElementsByTagName('defesa')
		if node_def:
			tipoDefesa = node_def[0].getAttribute('tipo').encode('utf-8')
			valorbase = node_def[0].getAttribute('valorbase')
			absorcao = node_def[0].getAttribute('absorcao')
			if tipoDefesa:
				item.tipoDefesa = tipoDefesa
			if valorbase:
				item.defesaBase = int(valorbase)
			if absorcao:
				item.absorcao = int(absorcao)

		node_hab = node.getElementsByTagName('habilidade')
		if node_hab:
			grupo = node_hab[0].getAttribute('grupo').encode('utf-8')
			if grupo:
				item.grupoHabilidade = grupo

		node_man = node.getElementsByTagName('manuseio')
		if node_man:
			pequenino = node_man[0].getAttribute('pequenino')
			anao = node_man[0].getAttribute('anao')
			elfo = node_man[0].getAttribute('elfo')
			humano = node_man[0].getAttribute('humano')
			forcaMinima = node_man[0].getAttribute('forcaMinima')
			if pequenino:
				item.manuseio['pequenino'] = int(pequenino)
			if anao:
				item.manuseio['anao'] = int(anao)
			if elfo:
				item.manuseio['elfo'] = int(elfo)
			if humano:
				item.manuseio['humano'] = int(humano)
			if forcaMinima:
				item.forcaMinima = int(forcaMinima)

		node_at = node.getElementsByTagName('ataque')
		if node_at:
			l0 = node_at[0].getAttribute('L0')
			m0 = node_at[0].getAttribute('M0')
			p0 = node_at[0].getAttribute('P0')
			dano = node_at[0].getAttribute('dano')
			if l0:
				item.ataque['L0'] = int(l0)
			if m0:
				item.ataque['M0'] = int(m0)
			if p0:
				item.ataque['P0'] = int(p0)
			if dano:
				item.dano = int(dano)

		equipamento.append(item)

	return equipamento

if __name__ == '__main__':
	'''
	print 'panteao ------------------------------------------------------------'
	print load_panteao(path.join('..', 'data', 'panteao.xml'))
	print 'magia --------------------------------------------------------------'
	for magia in load_grimoire(path.join('..', 'data', 'grimoire.xml')):
		print magia, '\n'
	'''
	print 'raca ---------------------------------------------------------------'
	racas = load_racas(path.join('..', 'data', 'racas.xml'))
	for key in racas.keys():
		print '\n', racas[key].altura

	print 'profissao ----------------------------------------------------------'
	for profissao in load_profissoes(path.join('..', 'data', 'profissoes.xml')):
		print '\n', profissao
		print profissao.atributo_para_magia
	'''
	print 'habilidade ---------------------------------------------------------'
	for habilidade in load_habilidades(path.join('..', 'data', 'habilidades.xml')):
		print '\n', habilidade
		pass
	print 'equipamento --------------------------------------------------------'
	for item in load_equipamento(path.join('..', 'data', 'equipamento.xml')):
		print '\n', item
	'''
