#!/usr/bin/python
#-*- coding:utf-8 -*-

# item_dialog.py
#
# Copyright (c) 2008 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
from os.path import join

import data
import guisupport as gs

class ItemDialog:

    (
    ITEM_VIEW,
    WEAPON_VIEW,
    DEFENSE_VIEW,
    WEAPDEF_VIEW
    ) = xrange(4)

    def __init__(self, wtree, store, pixbufspath):
        self.store = store
        self.item = None

        self.dialog = wtree.get_widget('item_dialog')
        self.dialog.add_buttons(gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE)

        self.item_label = wtree.get_widget('item_label')
        self.item_image = wtree.get_widget('item_image')
        self.item_image_viewport = wtree.get_widget('item_image_viewport')
        self.item_image_viewport.modify_bg(gtk.STATE_NORMAL, gs.COLOR_WHITE)

        self.item_desc_label = wtree.get_widget('item_desc_label')
        self.item_desc = wtree.get_widget('item_desc')
        self.item_desc_sw = wtree.get_widget('item_desc_sw')
        self.item_desc_textbuffer = gtk.TextBuffer()
        self.item_desc.set_buffer(self.item_desc_textbuffer)

        self.item_separator = wtree.get_widget('item_separator')

        self.item_def_table = wtree.get_widget('item_def_table')
        self.item_at_table = wtree.get_widget('item_at_table')
        self.item_at_hbox = wtree.get_widget('item_at_hbox')

        self.item_deftype_label = wtree.get_widget('item_deftype_label')
        self.item_defvalue_label = wtree.get_widget('item_defvalue_label')
        self.item_defabs_label = wtree.get_widget('item_defabs_label')

        self.item_atskill_label = wtree.get_widget('item_atskill_label')
        self.item_atminst_label = wtree.get_widget('item_atminst_label')
        self.item_atrange_label = wtree.get_widget('item_atrange_label')

        self.item_dmg_label = {
            25  : wtree.get_widget('item_dmg25_label'),
            50  : wtree.get_widget('item_dmg50_label'),
            75  : wtree.get_widget('item_dmg75_label'),
            100 : wtree.get_widget('item_dmg100_label')
        }

        self.item_atdef_l_label = wtree.get_widget('item_atdef_l_label')
        self.item_atdef_m_label = wtree.get_widget('item_atdef_m_label')
        self.item_atdef_p_label = wtree.get_widget('item_atdef_p_label')

        wtree.signal_autoconnect(self)

    # Callbacks ---------------------------------------------------------------
    def on_item_dialog_response(self, widget, response):
        self.dialog.hide()

    def on_item_dialog_delete_event(self, widget, event):
        self.dialog.hide()
        return True

    # Auxiliary Methods -------------------------------------------------------
    def set_item(self, item_id):
        self.item = self.store.get_equipment_item(item_id)
        if self.item is None:
            self.dialog.hide()
            return

        self.item_label.set_markup('<big><b>%s</b></big>' % self.item.name)

        self.reset_view()

        if type(self.item) == data.Weapon or \
           type(self.item) == data.Shield:
            self.set_damage()
            self.set_atdef_table()

            skill = self.store.get_skill_name(self.item.skill_id)
            try:
                skill_desc, skill_name = skill.split('(')
                skill_name = skill_name[:-1]
                self.item_atskill_label.set_text(skill_name)
                self.item_atskill_label.set_tooltip_text(skill_desc)
            except ValueError:
                self.item_atskill_label.set_text(skill)
                self.item_atskill_label.set_tooltip_text('')

            self.item_atminst_label.set_text(str(self.item.min_strength))
            if self.item.range == 0:
                self.item_atrange_label.set_text('---')
            else:
                self.item_atrange_label.set_text(str(self.item.range))

        if type(self.item) == data.Defense or \
           type(self.item) == data.Shield:
            if self.item.type is None:
                self.item_deftype_label.set_text('---')
            else:
                self.item_deftype_label.set_text(self.item.type)
            self.item_defvalue_label.set_text(str(self.item.base_defense))
            self.item_defabs_label.set_text(str(self.item.absorption))

        if self.item.description is not None:
            self.item_desc_textbuffer.set_text(self.item.description)
        else:
            self.item_desc_textbuffer.set_text('')


    def reset_view(self):
        if type(self.item) == data.Weapon or \
           type(self.item) == data.Shield:
            self.item_at_table.show()
            self.item_at_hbox.show()
        else:
            self.item_at_table.hide()
            self.item_at_hbox.hide()

        if type(self.item) == data.Defense or \
           type(self.item) == data.Shield:
            self.item_def_table.show()
        else:
            self.item_def_table.hide()

        if self.item.description is None:
            self.item_desc_label.hide()
            self.item_desc_sw.hide()
        else:
            self.item_desc_label.show()
            self.item_desc_sw.show()

        if type(self.item) == data.Shield:
            self.item_separator.show()
        else:
            self.item_separator.hide()

        if self.item.image is None:
            self.item_image.set_from_icon_name('gtk-dialog-question',
                                               gtk.ICON_SIZE_DIALOG)
        else:
            gr_dimension = max(self.item.image.get_width(),
                               self.item.image.get_height())
            img_size = self.item_image.get_property('width-request')

            if gr_dimension > img_size:
                scale = img_size / float(gr_dimension)
                width = int(self.item.image.get_width() * scale)
                height = int(self.item.image.get_height() * scale)
                pixbuf = self.item.image.scale_simple(width, height,
                                                      gtk.gdk.INTERP_NEAREST)

            else:
                pixbuf = self.item.image

            self.item_image.set_from_pixbuf(pixbuf)


    def set_damage(self):
        self.item_dmg_label[25].set_text(str(self.item.min_damage))
        self.item_dmg_label[50].set_text(str(self.item.min_damage * 2))
        self.item_dmg_label[75].set_text(str(self.item.min_damage * 3))
        self.item_dmg_label[100].set_text(str(self.item.min_damage * 4))

    def set_atdef_table(self):
        self.item_atdef_l_label.set_text(str(self.item.attack_defense['l']))
        self.item_atdef_m_label.set_text(str(self.item.attack_defense['m']))
        self.item_atdef_p_label.set_text(str(self.item.attack_defense['p']))

    def run(self):
        self.dialog.show()

