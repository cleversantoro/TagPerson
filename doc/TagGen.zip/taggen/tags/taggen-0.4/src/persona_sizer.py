#!/usr/bin/python
#-*- coding:utf-8 -*-

# persona_sizer.py
#
# Copyright (c) 2008 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
import random
from os.path import join

import data
import guisupport as gs

class PersonaSizer:

    MIN = 0
    MAX = 1
    MAX_HEIGHT = 200 # Altura maxima mostrada no widget
                     # de tamanho de personagem.

    def __init__(self, wtree, pixbufpath):
        self.height = 0
        self.weight = 0
        self.height_range = None
        self.weight_range = None

        self.image = wtree.get_widget('body_image')
        self.viewport = wtree.get_widget('body_viewport')
        self.height_vs = wtree.get_widget('height_vscale')
        self.weight_hs = wtree.get_widget('weight_hscale')

        dice_image = wtree.get_widget('dice_hw_img')
        dice_image.set_from_file(join(pixbufpath, 'dice.png'))

        self.background = gtk.gdk.pixbuf_new_from_file(join(pixbufpath,
                                                      'body_bg.png'))

        self.shadow = gtk.gdk.pixbuf_new_from_file(join(pixbufpath,
                                                   'shadow.png'))
        self.shadow_width = self.shadow.get_width()
        self.shadow_height = self.shadow.get_height()

        self.pixmap = gtk.gdk.Pixmap(None,
                                     self.image.allocation.width,
                                     self.image.allocation.height,
                                     gtk.gdk.visual_get_system().depth)

        self.viewport.modify_bg(gtk.STATE_NORMAL,
                                gs.COLOR_WHITE)

        self.image.set_from_pixbuf(self.background)

        wtree.signal_autoconnect(self)


    # Callbacks ---------------------------------------------------------------
    def on_hw_scale_value_changed(self, widget):
        if self.height_range is None or self.weight_range is None:
            return

        self.update()

    def on_random_hw_button_clicked(self, widget):
        if self.height_range is None or self.weight_range is None:
            return

        min_height, max_height = self.height_range
        min_weight, max_weight = self.weight_range
        height = random.randint(int(min_height), int(max_height))
        weight = random.randint(int(min_weight), int(max_weight))
        self.height_vs.set_value(height)
        self.weight_hs.set_value(weight)


    # Class Methods -----------------------------------------------------------
    def reset(self, race, hw=None):
        if hw is None:
            self.height = race.base_height
            self.weight = race.base_weight
        else:
            self.height, self.weight = hw

        self.height_range = race.calc_minmax_height()
        self.weight_range = race.calc_minmax_weight()

        lower, upper = self.height_range
        adj = gtk.Adjustment(self.height, lower, upper, 1)
        self.height_vs.set_adjustment(adj)

        lower, upper = self.weight_range
        adj = gtk.Adjustment(self.weight, lower, upper, 1)
        self.weight_hs.set_adjustment(adj)

        self.update()

    def get_height(self):
        return int(round(self.height_vs.get_value()))

    def get_weight(self):
        return int(round(self.weight_vs.get_value()))

    def scale(self):
        height = self.height_vs.get_value()
        weight = self.weight_hs.get_value()

        scale = min(self.image.allocation.width / float(self.shadow_width), \
                    self.image.allocation.height / float(self.shadow_height))
        h = int(round(self.shadow_height * scale * \
                (height / PersonaSizer.MAX_HEIGHT)))
        w = int(round(self.shadow_width * scale * \
                (weight / self.weight_range[PersonaSizer.MAX])))

        return self.shadow.scale_simple(w, h, gtk.gdk.INTERP_BILINEAR)

    def update(self):
        body_pixbuf = self.scale()

        self.pixmap.draw_pixbuf(None, self.background, 0, 0, 0, 0, -1, -1,
                                gtk.gdk.RGB_DITHER_NORMAL, 0, 0)

        w, h = self.pixmap.get_size()
        x = (w - body_pixbuf.get_width()) / 2
        y = h - body_pixbuf.get_height()

        self.pixmap.draw_pixbuf(None, body_pixbuf, 0, 0, x, y, -1, -1,
                                gtk.gdk.RGB_DITHER_NORMAL, 0, 0)

        self.image.set_from_pixmap(self.pixmap, None)

