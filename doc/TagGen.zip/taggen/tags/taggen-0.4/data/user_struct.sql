CREATE TABLE persona (
    id INTEGER PRIMARY KEY,
    name VARCHAR(100),
    player VARCHAR(100),
    image_file VARCHAR(60),
    att_intellect INTEGER,
    att_aura INTEGER,
    att_charisma INTEGER,
    att_strength INTEGER,
    att_physical INTEGER,
    att_agility INTEGER,
    att_perception INTEGER,

    active_defense INTEGER,
    passive_defense INTEGER,
    max_eh INTEGER,
    eh INTEGER,
    ef INTEGER,
    absorption INTEGER,

    race INTEGER,
    profession INTEGER,
    specialization INTEGER,
    level INTEGER,

    skill_points INTEGER,
    combat_points INTEGER,
    weapon_points INTEGER,
    magic_points INTEGER,

    height INTEGER,
    weight INTEGER,
    age INTEGER,

    eyes VARCHAR(60),
    hair VARCHAR(60),
    skin VARCHAR(60),
    appearance TEXT,

    god INTEGER,
    social_class VARCHAR(30),
    place_of_origin VARCHAR(60),
    history TEXT,

    copper_coins INTEGER,
    silver_coins INTEGER,
    gold_coins INTEGER
);

CREATE TABLE persona_item (
    persona_id INTEGER,
    item_id INTEGER,
    qtd INTEGER,
    PRIMARY KEY (persona_id, item_id)
);

CREATE TABLE persona_spell (
    persona_id INTEGER,
    spell_id INTEGER,
    level INTEGER,
    PRIMARY KEY (persona_id, spell_id)
);

CREATE TABLE persona_skill (
    persona_id INTEGER,
    skill_id INTEGER,
    level INTEGER,
    PRIMARY KEY (persona_id, skill_id)
);

CREATE TABLE persona_skill_specialization (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    persona_id INTEGER,
    skill_id INTEGER,
    specialization VARCHAR(40),
    level INTEGER
);
