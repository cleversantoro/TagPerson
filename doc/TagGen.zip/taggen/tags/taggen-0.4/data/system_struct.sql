CREATE TABLE skills (
    id INTEGER PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    bonus INTEGER,
    has_specialization INTEGER
);

CREATE TABLE skill_specialization_suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id INTEGER,
    suggestion VARCHAR(40)
);

CREATE TABLE skill_groups (
    id INTEGER PRIMARY KEY,
    parent_id INTEGER,
    name VARCHAR(100)
);

CREATE TABLE skill2group (
    skill_id INTEGER,
    skillgroup_id INTEGER,
    cost INTEGER,
    PRIMARY KEY (skill_id, skillgroup_id)
);

CREATE TABLE spells (
    id INTEGER PRIMARY KEY,
    name VARCHAR(60),
    description TEXT,
    evocation VARCHAR(40),
    range VARCHAR(40),
    duration VARCHAR(60)
);

CREATE TABLE spell_groups (
    id INTEGER PRIMARY KEY,
    parent_id INTEGER,
    name VARCHAR(100)
);

CREATE TABLE spell2group (
    spell_id INTEGER,
    spellgroup_id INTEGER,
    cost INTEGER,
    PRIMARY KEY (spell_id, spellgroup_id)
);

CREATE TABLE equipment_groups (
    id INTEGER PRIMARY KEY,
    name VARCHAR(60)
);

CREATE TABLE equipment (
    id INTEGER PRIMARY KEY,
    group_id INTEGER,
    name VARCHAR(60),
    description VARCHAR(160),
    image_file VARCHAR(50),
    price INTEGER,
    weapon INTEGER,
    defense INTEGER
);

CREATE TABLE equipment_weapons (
    id INTEGER PRIMARY KEY,
    skill_id INTEGER,
    min_strength INTEGER,
    min_damage INTEGER,
    l0 INTEGER,
    m0 INTEGER,
    p0 INTEGER,
    range INTEGER
);

CREATE TABLE equipment_defense (
    id INTEGER PRIMARY KEY,
    type VARCHAR(10),
    base_value INTEGER,
    absorption INTEGER
);

CREATE TABLE races (
    id INTEGER PRIMARY KEY,
    name VARCHAR(60),
    image_file VARCHAR(60),
    attr_int INTEGER,
    attr_aur INTEGER,
    attr_car INTEGER,
    attr_for INTEGER,
    attr_fis INTEGER,
    attr_agi INTEGER,
    attr_per INTEGER,
    base_speed INTEGER,
    ef INTEGER,
    base_height INTEGER,
    base_weight INTEGER,
    age_min INTEGER,
    age_max INTEGER
);

CREATE TABLE professions (
    id INTEGER PRIMARY KEY,
    name VARCHAR(60),
    image_file VARCHAR(60),
    description TEXT,
    copper_coins INTEGER,
    eh INTEGER,
    skill_points INTEGER,
    weapon_points INTEGER,
    combat_points INTEGER,
    penalized_skillgroup INTEGER,
    specialized_skill INTEGER,
    attribute_for_magic INTEGER,
    spell_group_id INTEGER
);

CREATE TABLE specializations (
    id INTEGER PRIMARY KEY,
    name VARCHAR(60),
    description TEXT,
    profession_id INTEGER,
    spell_group_id INTEGER,
    technique_group_id INTEGER
);

CREATE TABLE race_profession (
    race_id INTEGER,
    profession_id INTEGER,
    PRIMARY KEY (race_id, profession_id)
);

CREATE TABLE gods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(60),
    realm VARCHAR(100)
);

-- FIXME: futuramente adicionar coordenadas, baseadas em TagMap
CREATE TABLE places (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_id INTEGER DEFAULT -1,
    name VARCHAR(60),
    crest VARCHAR(60),
    x INTEGER DEFAULT 0,
    y INTEGER DEFAULT 0,
    quote TEXT,
    q_author VARCHAR(120)
);

CREATE TABLE timeline (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    place_id INTEGER,
    year INTEGER,
    event VARCHAR(300)
);
