#!/usr/bin/python
#-*- coding:utf-8 -*-

# persona_dialog.py
#
# Copyright (c) 2007 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade
from os.path import join

import data
import core
import guisupport as gs

(
RACES_COL_ID,
RACES_COL_PIXBUF,
RACES_COL_TEXT,
RACES_COL_TOOLTIP,
RACES_COL_OBJECT
) = range(5)

(
PROFS_COL_ID,
PROFS_COL_PIXBUF,
PROFS_COL_TEXT,
PROFS_COL_TOOLTIP,
PROFS_COL_OBJECT
) = range(5)

class PersonaDialog:
    def __init__(self, wtree, store, pixmapspath, gtk_ok=False):
        self.store = store
        self.GTK_VERSION_OK = gtk_ok

        self.dialog = wtree.get_widget('persona_dialog')
        self.dialog.add_buttons(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                                gtk.STOCK_OK, gtk.RESPONSE_OK)

        self.races_iconview = wtree.get_widget('races_iconview')
        self.races_model = self.init_races()
        self.profs_iconview = wtree.get_widget('profs_iconview')
        self.profs_model, self.profs_filter = self.init_professions()
        self.side_image = wtree.get_widget('wizard_image')
        self.side_image.set_from_file(join(pixmapspath, 'tagmar_capa_berbert.png'))

        wtree.signal_autoconnect(self)

    # Callbacks ---------------------------------------------------------------
    def on_races_iconview_selection_changed(self, iconview):
        self.profs_filter.refilter()

    def on_persona_dialog_delete_event(self, widget, event):
        self.dialog.hide()
        return True

    # Auxiliary Methods -------------------------------------------------------
    def init_races(self):
        model = gtk.ListStore(int, gtk.gdk.Pixbuf, str, str, data.Race)
        self.races_iconview.set_model(model)
        self.races_iconview.set_pixbuf_column(RACES_COL_PIXBUF)
        self.races_iconview.set_text_column(RACES_COL_TEXT)
        if self.GTK_VERSION_OK:
            self.races_iconview.set_tooltip_column(RACES_COL_TOOLTIP)

        for race_id, race_name in self.store.get_races_list():
            race = self.store.get_race(race_id)

            tooltip = '<big><b>%s</b></big>\n\n' % race.name
            bonuses = []
            for i in range(len(race.attribute_bonus)):
                if race.attribute_bonus[i] != 0:
                    bonuses.append('%s %+d' % (data.ATTRIBUTE_SHORT_NAMES[i],
                                                 race.attribute_bonus[i]))
            if len(bonuses) > 0:
                tooltip += '<b>Bônus:</b> ' + ', '.join(bonuses) + '\n\n'

            tooltip += '<b>EF Base:</b> %d\n<b>Velocidade Base:</b> %d\n' \
                       '<b>Altura Média:</b> %.2fm\n<b>Peso Médio:</b> ' \
                       '%dkg\n\nPersonagens iniciantes costumam\n' \
                       'ter entre %d e %d anos de idade.' % \
                       (race.ef, race.base_speed, race.base_height / 100.0,
                        race.base_weight, race.age[0], race.age[1])

            model.append([race_id, race.image, race_name, tooltip, race])

        return model


    def init_professions(self):
        model = gtk.ListStore(int, gtk.gdk.Pixbuf, str, str, data.Profession)
        filter = model.filter_new()
        self.profs_iconview.set_model(filter)
        filter.set_visible_func(self.professions_visible, data=None)
        self.profs_iconview.set_pixbuf_column(PROFS_COL_PIXBUF)
        self.profs_iconview.set_text_column(PROFS_COL_TEXT)
        if self.GTK_VERSION_OK:
            self.profs_iconview.set_tooltip_column(PROFS_COL_TOOLTIP)

        for prof_id, prof_name in self.store.get_professions_list():
            prof = self.store.get_profession(prof_id)

            tooltip = '<big><b>%s</b></big>\n\n<b>EH Base:</b> %d\n' \
                      '<b>Pts de Habilidades:</b> %d\n' \
                      '<b>Pts de Hab. com Armas:</b> %d\n' \
                      '<b>Pts. de Técnicas de Combate:</b> %d' % \
                      (prof.name, prof.eh, prof.skill_points,
                       prof.weapon_points, prof.combat_points)

            if prof.penalized_skill_group > -1:
                tooltip += '\n<b>Grupo de Hab. Penalizado:</b> %s' % \
                           self.store.get_skill_group_name(prof.penalized_skill_group)

            if prof.specialization_skill > -1:
                tooltip += '\n<b>Habilidade especializada:</b> %s' % \
                           self.store.get_skill_name(prof.specialization_skill)

            if prof.attribute_for_magic > -1:
                tooltip += '\n\n<b>Atributo para Magia:</b> %s' % \
                           data.ATTRIBUTE_NAMES[prof.attribute_for_magic]

            model.append([prof_id, prof.image, prof_name, tooltip, prof])

        return model, filter


    def get_selected_race(self):
        cursor = self.races_iconview.get_cursor()
        if cursor is None:
            return None

        iter2 = self.races_model.get_iter(cursor[0])
        return self.races_model.get(iter2, RACES_COL_OBJECT)[0]


    def get_selected_profession(self):
        cursor = self.profs_iconview.get_cursor()
        if cursor is None:
            return None

        iter2 = self.profs_filter.get_iter(cursor[0])
        return self.profs_filter.get(iter2, PROFS_COL_OBJECT)[0]


    def professions_visible(self, model, iter, user_data):
        if self.races_iconview is not None:
            race = self.get_selected_race()
            if race is not None:
                prof_id = model.get(iter, PROFS_COL_ID)[0]
                return (prof_id in race.available_professions)

        return True


    def run(self):
        self.races_iconview.unselect_all()
        self.profs_iconview.unselect_all()
        self.profs_filter.refilter() #FIXME: nao funciona quando o dialogo eh aberto novamente
        self.dialog.show()

