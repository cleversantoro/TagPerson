-- GODS (id, name, realm)
INSERT INTO gods (name, realm) VALUES ("Sevides", "agricultura, fertilidade");
INSERT INTO gods (name, realm) VALUES ("Quiris", "plantio");
INSERT INTO gods (name, realm) VALUES ("Liris", "colheita");
INSERT INTO gods (name, realm) VALUES ("Ganis", "água, mar");
INSERT INTO gods (name, realm) VALUES ("Blator", "guerra, conflito");
INSERT INTO gods (name, realm) VALUES ("Crisagom", "honra, estratégia, bravura");
INSERT INTO gods (name, realm) VALUES ("Crezir", "fúria matança, prazer da luta");
INSERT INTO gods (name, realm) VALUES ("Maira mon", "natureza em aspecto mineral");
INSERT INTO gods (name, realm) VALUES ("Maira vet", "natureza em aspecto vegetal");
INSERT INTO gods (name, realm) VALUES ("Maira nil", "natureza em aspecto animal");
INSERT INTO gods (name, realm) VALUES ("Selimon", "paz, amor");
INSERT INTO gods (name, realm) VALUES ("Lena", "prazer erótico e prazer no trabalho");
INSERT INTO gods (name, realm) VALUES ("Plandis", "paixão cega loucura");
INSERT INTO gods (name, realm) VALUES ("Cambu", "diplomacia, comércio, inter-relações");
INSERT INTO gods (name, realm) VALUES ("Cruine", "morte, protetor das almas, reincarnação");
INSERT INTO gods (name, realm) VALUES ("Palier", "conhecimento, magia");
INSERT INTO gods (name, realm) VALUES ("Parom", "artífices");

-- PLACES (id, name)
INSERT INTO places (id, name) VALUES (1, "Levânia");
INSERT INTO places (id, name) VALUES (2, "Eredra");
INSERT INTO places (id, name) VALUES (3, "Verrogar");
INSERT INTO places (id, name) VALUES (4, "Calco");
INSERT INTO places (id, name) VALUES (5, "Plana");
INSERT INTO places (id, name) VALUES (6, "Acordo");
INSERT INTO places (id, name) VALUES (7, "Porto Livre");
INSERT INTO places (id, name) VALUES (8, "Azanti");
INSERT INTO places (id, name) VALUES (9, "Dantsen");
INSERT INTO places (id, name) VALUES (10, "Conti");
INSERT INTO places (id, name) VALUES (11, "Filanti");
INSERT INTO places (id, name) VALUES (12, "Marana");
INSERT INTO places (id, name) VALUES (13, "Luna");
INSERT INTO places (id, name) VALUES (14, "Portis");
INSERT INTO places (id, name) VALUES (15, "As Cidades");
INSERT INTO places (id, name) VALUES (16, "Ludgrim");
INSERT INTO places (id, name) VALUES (17, "Abadom");

INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Sadom");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Rokor");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Ingru");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Dameste");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Sika");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Beruni");
INSERT INTO places (parent_id, name) VALUES (1, "Cidade de Altarap");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Efrin");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Itéria");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Brual");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Diam");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Igara");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Samor");
INSERT INTO places (parent_id, name) VALUES (2, "Cidade de Tanue");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Treva");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Fontenova");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Sula");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Lutrúcia");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Crássia");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Seviala");
INSERT INTO places (parent_id, name) VALUES (3, "Cidade de Aberdim");

INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Saravossa");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Malocai");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Carom");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Bassani");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Torojai");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Saupami");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Tória");
INSERT INTO places (parent_id, name) VALUES (4, "Cidade de Abrasil");

INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Caleonir");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Aradelis");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Porto Velho");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Balistro");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Omarge");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Cipa");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Alimar");
INSERT INTO places (parent_id, name) VALUES (5, "Cidade de Pórtis");

INSERT INTO places (parent_id, name) VALUES (6, "Cidade de Porto Áureo");
INSERT INTO places (parent_id, name) VALUES (6, "Cidade de Palom");
INSERT INTO places (parent_id, name) VALUES (6, "Cidade de Coberae");
INSERT INTO places (parent_id, name) VALUES (6, "Cidade de Minas Mon");
INSERT INTO places (parent_id, name) VALUES (6, "Cidade de Pratissi");

INSERT INTO places (parent_id, name) VALUES (7, "Cidade de Quessedir");

INSERT INTO places (parent_id, name) VALUES (8, "Cidade de Zanta");
INSERT INTO places (parent_id, name) VALUES (8, "Cidade de Grabo");
INSERT INTO places (parent_id, name) VALUES (8, "Cidade de Mirval");

INSERT INTO places (parent_id, name) VALUES (9, "Cidade de Léon");
INSERT INTO places (parent_id, name) VALUES (9, "Cidade de Calinior");
INSERT INTO places (parent_id, name) VALUES (9, "Cidade de Novini");
INSERT INTO places (parent_id, name) VALUES (9, "Cidade de Porteval");
INSERT INTO places (parent_id, name) VALUES (9, "Cidade de Isalibel");

INSERT INTO places (parent_id, name) VALUES (10, "Cidade de Muli");
INSERT INTO places (parent_id, name) VALUES (10, "Cidade de Ambernita");
INSERT INTO places (parent_id, name) VALUES (10, "Cidade de Pontalina");
INSERT INTO places (parent_id, name) VALUES (10, "Cidade de Ruínas de Moldazi");
INSERT INTO places (parent_id, name) VALUES (10, "Cidade de Virena");

INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Chats");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Fétor");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Agrápia");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Pacri");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Povariana");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Capela");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Mutina");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Litória Nova");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Pechara");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Rapso");
INSERT INTO places (parent_id, name) VALUES (11, "Cidade de Verda");

INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Sensera");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Litória");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Magiara");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Caliana");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Chipara");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Lubliama");
INSERT INTO places (parent_id, name) VALUES (12, "Cidade de Portiara");

INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Franges");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Lagia");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Obrem");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Calisto");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Dariati");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Varteli");
INSERT INTO places (parent_id, name) VALUES (13, "Cidade de Porto Coral");

INSERT INTO places (parent_id, name) VALUES (14, "Cidade de Runa");
INSERT INTO places (parent_id, name) VALUES (14, "Cidade de Maginor");
INSERT INTO places (parent_id, name) VALUES (14, "Cidade de Estenorial");
INSERT INTO places (parent_id, name) VALUES (14, "Cidade de Tanus");

INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Pino");
INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Novo Porto");
INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Quizes");
INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Torbel");
INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Ender");
INSERT INTO places (parent_id, name) VALUES (15, "Cidade-Estado de Estepe");

INSERT INTO places (parent_id, name) VALUES (16, "Cidade de Donatar");
INSERT INTO places (parent_id, name) VALUES (16, "Cidade de Grima");
INSERT INTO places (parent_id, name) VALUES (16, "Cidade de Serfa");
INSERT INTO places (parent_id, name) VALUES (16, "Forte Galatel");
INSERT INTO places (parent_id, name) VALUES (16, "Vila Timor");
INSERT INTO places (parent_id, name) VALUES (16, "Cidade de Balinor");
INSERT INTO places (parent_id, name) VALUES (16, "Cidade de Agrimir");

INSERT INTO places (parent_id, name) VALUES (17, "Cidade de Fleuter");
INSERT INTO places (parent_id, name) VALUES (17, "Cidade de Deiamom");
INSERT INTO places (parent_id, name) VALUES (17, "Cidade de Tronum");
INSERT INTO places (parent_id, name) VALUES (17, "Cidade de Ferco");
INSERT INTO places (parent_id, name) VALUES (17, "Vila nômade de Anguinadar");

INSERT INTO places (name) VALUES ("Floresta Finlaril");
INSERT INTO places (name) VALUES ("Floresta Fiorna");
INSERT INTO places (name) VALUES ("Floresta Melgundi");
INSERT INTO places (name) VALUES ("Floresta de Siltam");
INSERT INTO places (name) VALUES ("Floresta Âmien");
INSERT INTO places (name) VALUES ("Floresta Gironde");
INSERT INTO places (name) VALUES ("Montes Moncurianos");
INSERT INTO places (name) VALUES ("Deserto de Blirga");
INSERT INTO places (name) VALUES ("Dartel");
INSERT INTO places (name) VALUES ("A Ilha");
INSERT INTO places (name) VALUES ("Condado Élfico de Lirati");
INSERT INTO places (name) VALUES ("Lar, o Reino Élfico");
INSERT INTO places (name) VALUES ("A Geleira");
INSERT INTO places (name) VALUES ("A Forja");
INSERT INTO places (name) VALUES ("Cidade de Telas");

-- RACES (id, name, image_file, attr_int, attr_aur, attr_car, attr_for,
--        attr_fis, attr_agi, attr_per, base_speed, ef, base_height,
--        base_weight, age_min, age_max)
INSERT INTO races VALUES (1, "Humano", "humano.png", 0, 0, 0, 0, 0, 0, 0, 18, 14, 177, 77, 16, 25);
INSERT INTO races VALUES (2, "Pequenino", "pequenino.png", 0, 0, 0, -2, 1, 2, 1, 12, 11, 114, 30, 16, 25);
INSERT INTO races VALUES (3, "Anão", "anao.png", 0, -1, 0, 1, 2, -1, 0, 14, 12, 139, 53, 25, 100);
INSERT INTO races VALUES (4, "Elfo Florestal", "elfoflorestal.png", 1, 0, 0, 0, -1, 1, 1, 16, 12, 163, 53, 25, 300);
INSERT INTO races VALUES (5, "Elfo Dourado", "elfodourado.png", 1, 1, 1, -1, -1, 1, 0, 16, 12, 163, 53, 25, 300);
INSERT INTO races VALUES (6, "Meio-elfo", "meioelfo.png", 0, 0, 1, 0, 0, 0, 0, 17, 13, 168, 69, 25, 100);

-- PROFESSIONS (id, name, image_file, description, copper_coins, eh,
--              skill_points, weapon_points, combat_points,
--              penalized_skillgroup, specialized_skill,
--              attribute_for_magic, spell_group_id)
INSERT INTO professions VALUES (1, "Guerreiro", "guerreiro.png", "Guerreiros fazem a guerra.", 5, 18, 14, 7, 7, 7, -1, -1, -1);
INSERT INTO professions VALUES (2, "Ladino", "ladino.png", "Ladinos fazem ladinagem.", 5, 12, 22, 7, 7, -1, -1, -1, -1);
INSERT INTO professions VALUES (3, "Sacerdote", "sacerdote.png", "Sacerdote oram.", 5, 12, 12, 5, 4, 5, -1, 2, 3);
INSERT INTO professions VALUES (4, "Mago", "mago.png", "Magos fazem mágica.", 5, 6, 12, 5, 4, 6, -1, 0, 4);
INSERT INTO professions VALUES (5, "Rastreador", "rastreador.png", "Rastreadores seguem trilhas.", 5, 15, 14, 5, 4, 4, -1, 6, 1);
INSERT INTO professions VALUES (6, "Bardo", "bardo.png", "Bardos contam histórias.", 5, 9, 16, 5, 4, -1, -1, 2, 2);

-- SPECIALIZATIONS (id, name, description,
--                  profession_id, spell_group_id, technique_group_id)
INSERT INTO specializations VALUES (1, "Academia de Infantaria", NULL, 1, -1, 10);
INSERT INTO specializations VALUES (2, "Academia dos Arqueiros", NULL, 1, -1, 11);
INSERT INTO specializations VALUES (3, "Academia dos Cavaleiros", NULL, 1, -1, 12);
INSERT INTO specializations VALUES (4, "Academia dos Gladiadores", NULL, 1, -1, 13);

INSERT INTO specializations VALUES (5, "Guilda dos Ladrões", NULL, 2, -1, -1);
INSERT INTO specializations VALUES (6, "Guilda dos Assassinos", NULL, 2, -1, -1);
INSERT INTO specializations VALUES (7, "Guilda dos Piratas", NULL, 2, -1, -1);

INSERT INTO specializations VALUES (8, "Ordem de Selimon", NULL, 3, 11, -1);
INSERT INTO specializations VALUES (9, "Ordem de Sevides", NULL, 3, 12, -1);
INSERT INTO specializations VALUES (10, "Ordem de Ganis", NULL, 3, 13, -1);
INSERT INTO specializations VALUES (11, "Ordem de Parom", NULL, 3, 14, -1);
INSERT INTO specializations VALUES (12, "Ordem de Crizagom", NULL, 3, 15, -1);
INSERT INTO specializations VALUES (13, "Ordem de Crezir", NULL, 3, 16, -1);
INSERT INTO specializations VALUES (14, "Ordem de Blator", NULL, 3, 17, -1);
INSERT INTO specializations VALUES (15, "Ordem de Cruine", NULL, 3, 18, -1);
INSERT INTO specializations VALUES (16, "Ordem de Cambu", NULL, 3, 19, -1);
INSERT INTO specializations VALUES (17, "Ordem de Palier", NULL, 3, 20, -1);
INSERT INTO specializations VALUES (18, "Ordem de Plandis", NULL, 3, 21, -1);
INSERT INTO specializations VALUES (19, "Ordem de Lena", NULL, 3, 22, -1);
INSERT INTO specializations VALUES (20, "Ordem de Maira", NULL, 3, 23, -1);

INSERT INTO specializations VALUES (21, "Colégio Elemental", NULL, 4, 24, -1);
INSERT INTO specializations VALUES (22, "Colégio Necromântico", NULL, 4, 25, -1);
INSERT INTO specializations VALUES (23, "Colégio Ilusão", NULL, 4, 26, -1);
INSERT INTO specializations VALUES (24, "Colégio Naturalista", NULL, 4, 27, -1);
INSERT INTO specializations VALUES (25, "Colégio Alquímico", NULL, 4, 28, -1);
INSERT INTO specializations VALUES (26, "Colégio Conhecimento", NULL, 4, 29, -1);

INSERT INTO specializations VALUES (27, "Trilha dos Caçadores", NULL, 5, 5, -1);
INSERT INTO specializations VALUES (28, "Trilha dos Exploradores", NULL, 5, 6, -1);
INSERT INTO specializations VALUES (29, "Trilha dos Guardiões", NULL, 5, 7, -1);

INSERT INTO specializations VALUES (30, "Confraria dos Arautos", NULL, 6, 8, -1);
INSERT INTO specializations VALUES (31, "Confraria dos Artistas", NULL, 6, 9, -1);
INSERT INTO specializations VALUES (32, "Confraria dos Eruditos", NULL, 6, 10, -1);

-- RACE_PROFESSION (race_id, profession_id)
INSERT INTO race_profession VALUES (1, 1);
INSERT INTO race_profession VALUES (1, 2);
INSERT INTO race_profession VALUES (1, 3);
INSERT INTO race_profession VALUES (1, 4);
INSERT INTO race_profession VALUES (1, 5);
INSERT INTO race_profession VALUES (1, 6);

INSERT INTO race_profession VALUES (2, 1);
INSERT INTO race_profession VALUES (2, 2);
INSERT INTO race_profession VALUES (2, 3);

INSERT INTO race_profession VALUES (3, 1);
INSERT INTO race_profession VALUES (3, 2);
INSERT INTO race_profession VALUES (3, 3);

INSERT INTO race_profession VALUES (4, 1);
INSERT INTO race_profession VALUES (4, 2);
INSERT INTO race_profession VALUES (4, 3);
INSERT INTO race_profession VALUES (4, 4);
INSERT INTO race_profession VALUES (4, 5);
INSERT INTO race_profession VALUES (4, 6);

INSERT INTO race_profession VALUES (5, 1);
INSERT INTO race_profession VALUES (5, 2);
INSERT INTO race_profession VALUES (5, 3);
INSERT INTO race_profession VALUES (5, 4);
INSERT INTO race_profession VALUES (5, 5);
INSERT INTO race_profession VALUES (5, 6);

INSERT INTO race_profession VALUES (6, 1);
INSERT INTO race_profession VALUES (6, 2);
INSERT INTO race_profession VALUES (6, 3);
INSERT INTO race_profession VALUES (6, 4);
INSERT INTO race_profession VALUES (6, 5);
INSERT INTO race_profession VALUES (6, 6);

-- SKILLS (id, name, description, bonus, has_specialization)
INSERT INTO skills VALUES (1, "Carpintaria", NULL, 5, 0);
INSERT INTO skills VALUES (2, "Engenharia", NULL, 0, 0);
INSERT INTO skills VALUES (3, "Medicina", NULL, 0, 0);
INSERT INTO skills VALUES (4, "Náutica", NULL, 6, 0);
INSERT INTO skills VALUES (5, "Trabalho em Metal", NULL, 6, 0);
INSERT INTO skills VALUES (6, "Trabalhos Manuais", NULL, 5, 0);

INSERT INTO skills VALUES (7, "Acrobacias", NULL, 5, 0);
INSERT INTO skills VALUES (8, "Corrida", "Basicamente consiste na capacidade de correr mais rapidamente devido a intensivo treinamento. Uma habilidade muito desenvolvida por animais corredores como cavalos, mas também extremamente eficaz quando usada por humanóides.", 5, 0);
INSERT INTO skills VALUES (9, "Escalar Superfícies", NULL, 5, 0);
INSERT INTO skills VALUES (10, "Malabarismo", NULL, 5, 0);
INSERT INTO skills VALUES (11, "Montar Animais", NULL, 5, 0);
INSERT INTO skills VALUES (12, "Natação", NULL, 4, 0);

INSERT INTO skills VALUES (13, "Escrita", NULL, 0, 1);
INSERT INTO skills VALUES (14, "Herbalismo", NULL, 0, 0);
INSERT INTO skills VALUES (15, "Língua", NULL, 0, 1);
INSERT INTO skills VALUES (16, "Misticismo", NULL, 0, 0);
INSERT INTO skills VALUES (17, "Religião", NULL, 0, 0);
INSERT INTO skills VALUES (18, "Venefício", "Quem possuir esta habilidade terá um conhecimento sobre venenos, incluindo o seu preparo e utilização.", 0, 0);

INSERT INTO skills VALUES (19, "Ações Furtivas", NULL, 5, 0);
INSERT INTO skills VALUES (20, "Destrancar Fechaduras", NULL, 5, 0);
INSERT INTO skills VALUES (21, "Disfarces", NULL, 6, 0);
INSERT INTO skills VALUES (22, "Escapar", NULL, 5, 0);
INSERT INTO skills VALUES (23, "Falsificação", NULL, 6, 0);
INSERT INTO skills VALUES (24, "Furtar Objetos", NULL, 5, 0);
INSERT INTO skills VALUES (25, "Jogatina", NULL, 6, 0);

INSERT INTO skills VALUES (26, "Arte", NULL, 2, 1);
INSERT INTO skills VALUES (27, "Barganha", NULL, 2, 0);
INSERT INTO skills VALUES (28, "Comércio", NULL, 6, 0);
INSERT INTO skills VALUES (29, "Etiqueta", NULL, 2, 0);
INSERT INTO skills VALUES (30, "Liderança", NULL, 2, 0);
INSERT INTO skills VALUES (31, "Persuasão", NULL, 2, 0);
INSERT INTO skills VALUES (32, "Sedução", NULL, 2, 0);

INSERT INTO skills VALUES (33, "Escutar", NULL, 6, 0);
INSERT INTO skills VALUES (34, "Lidar com Animais", NULL, 6, 0);
INSERT INTO skills VALUES (35, "Manusear Armadilhas", NULL, 6, 0);
INSERT INTO skills VALUES (36, "Navegação", NULL, 6, 0);
INSERT INTO skills VALUES (37, "Observar", NULL, 6, 0);
INSERT INTO skills VALUES (38, "Seguir Trilhas", NULL, 6, 0);
INSERT INTO skills VALUES (39, "Sobrevivência", NULL, 6, 0);

INSERT INTO skills VALUES (50, "Combate desarmado (Cd)", NULL, 5, 0);
INSERT INTO skills VALUES (51, "Corte leve (Cl)", NULL, 5, 0);
INSERT INTO skills VALUES (52, "Esmagamento leve (El)", NULL, 5, 0);
INSERT INTO skills VALUES (53, "Corte médio com Espada (CmE)", NULL, 5, 0);
INSERT INTO skills VALUES (54, "Corte médio com Machado (CmM)", NULL, 5, 0);
INSERT INTO skills VALUES (55, "Esmagamento médio (Em)", NULL, 5, 0);
INSERT INTO skills VALUES (56, "Perfuração média com Arco (PmA)", NULL, 5, 0);
INSERT INTO skills VALUES (57, "Perfuração média com Lança (PmL)", NULL, 5, 0);
INSERT INTO skills VALUES (58, "Corte pesado com Espada (CpE)", NULL, 5, 0);
INSERT INTO skills VALUES (59, "Corte pesado com Machado (CpM)", NULL, 5, 0);
INSERT INTO skills VALUES (60, "Esmagamento pesado (Ep)", NULL, 5, 0);
INSERT INTO skills VALUES (61, "Perfuração pesada (Pp)", NULL, 5, 0);

-- SKILLS (id, name, description, bonus, has_specialization)
INSERT INTO skills VALUES (80, "Ambidestria", NULL, -1, 0);
INSERT INTO skills VALUES (81, "Aparar", NULL, -1, 0);
INSERT INTO skills VALUES (82, "Ataque Oportuno", NULL, 6, 0);
INSERT INTO skills VALUES (83, "Ataque de Surpresa", NULL, 6, 0);
INSERT INTO skills VALUES (84, "Atirar em Movimento", NULL, 5, 0);
INSERT INTO skills VALUES (85, "Carga", NULL, -1, 0);
INSERT INTO skills VALUES (86, "Combate Montado", NULL, -1, 0);
INSERT INTO skills VALUES (87, "Esquiva", NULL, 5, 0);
INSERT INTO skills VALUES (88, "Luta às Cegas", NULL, -1, 0);
INSERT INTO skills VALUES (89, "Resistência à Dor", NULL, 4, 0);
INSERT INTO skills VALUES (90, "Combate não Letal", NULL, 6, 0);

INSERT INTO skills VALUES (91, "Força Interior", NULL, -1, 0);
INSERT INTO skills VALUES (92, "Golpe Giratório", NULL, 5, 0);
INSERT INTO skills VALUES (93, "Golpe Letal", NULL, -1, 0);
INSERT INTO skills VALUES (94, "Resistência à Dor", NULL, 4, 0);
INSERT INTO skills VALUES (95, "Voz de Comando", NULL, 6, 0);

INSERT INTO skills VALUES (96, "Combate com Arco", NULL, 5, 0);
INSERT INTO skills VALUES (97, "Direcionamento", NULL, 6, 0);
INSERT INTO skills VALUES (98, "Flechada Dupla", NULL, -1, 0);
INSERT INTO skills VALUES (99, "Mira", NULL, -1, 0);

INSERT INTO skills VALUES (100, "Carga de Arremesso", NULL, -1, 0);
INSERT INTO skills VALUES (101, "Carga Montada", NULL, -1, 0);
INSERT INTO skills VALUES (102, "Combate com Escudo** 2 Agi", NULL, 5, 0);

INSERT INTO skills VALUES (103, "Contra-ataque", NULL, -1, 0);
INSERT INTO skills VALUES (104, "Desequilibrar", NULL, -1, 0);
INSERT INTO skills VALUES (105, "Fúria", NULL, -1, 0);
INSERT INTO skills VALUES (106, "Intimidar", NULL, 2, 0);


-- SKILL_SPECIALIZATION_SUGGESTIONS (id, skill_id, suggestion)
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Canto");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Dança");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Música");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Poesia");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Desenho/Pintura");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (26, "Escultura");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Malês meridional");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Malês central");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Malês setentrional");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Élfico");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Lantranês");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (13, "Órquico");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (15, "Malês meridional");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (15, "Malês central");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (15, "Malês setentrional");
INSERT INTO skill_specialization_suggestions (skill_id, suggestion) VALUES (15, "Élfico");

-- SKILL_GROUPS (id, parent_id, name)
INSERT INTO skill_groups VALUES (1, -1, "Habilidades Comuns");
INSERT INTO skill_groups VALUES (2, -1, "Habilidades com Armas");
INSERT INTO skill_groups VALUES (3, -1, "Técnicas de Combate");

INSERT INTO skill_groups VALUES (4, 1, "Profissional");
INSERT INTO skill_groups VALUES (5, 1, "Subterfúgio");
INSERT INTO skill_groups VALUES (6, 1, "Manobra");
INSERT INTO skill_groups VALUES (7, 1, "Influência");
INSERT INTO skill_groups VALUES (8, 1, "Conhecimento");
INSERT INTO skill_groups VALUES (9, 1, "Geral");

INSERT INTO skill_groups VALUES (10, 3, "Academia de Infantaria");
INSERT INTO skill_groups VALUES (11, 3, "Academia dos Arqueiros");
INSERT INTO skill_groups VALUES (12, 3, "Academia dos Cavaleiros");
INSERT INTO skill_groups VALUES (13, 3, "Academia dos Gladiadores");

-- SKILL2GROUP (skill_id, skillgroup_id, cost)
INSERT INTO skill2group VALUES (1, 4, 1);
INSERT INTO skill2group VALUES (2, 4, 2);
INSERT INTO skill2group VALUES (3, 4, 2);
INSERT INTO skill2group VALUES (4, 4, 1);
INSERT INTO skill2group VALUES (5, 4, 2);
INSERT INTO skill2group VALUES (6, 4, 1);

INSERT INTO skill2group VALUES (7, 6, 2);
INSERT INTO skill2group VALUES (8, 6, 1);
INSERT INTO skill2group VALUES (9, 6, 2);
INSERT INTO skill2group VALUES (10, 6, 2);
INSERT INTO skill2group VALUES (11, 6, 1);
INSERT INTO skill2group VALUES (12, 6, 1);

INSERT INTO skill2group VALUES (13, 8, 2);
INSERT INTO skill2group VALUES (14, 8, 2);
INSERT INTO skill2group VALUES (15, 8, 2);
INSERT INTO skill2group VALUES (16, 8, 2);
INSERT INTO skill2group VALUES (17, 8, 2);
INSERT INTO skill2group VALUES (18, 8, 2);

INSERT INTO skill2group VALUES (19, 5, 2);
INSERT INTO skill2group VALUES (20, 5, 1);
INSERT INTO skill2group VALUES (21, 5, 2);
INSERT INTO skill2group VALUES (22, 5, 1);
INSERT INTO skill2group VALUES (23, 5, 2);
INSERT INTO skill2group VALUES (24, 5, 1);
INSERT INTO skill2group VALUES (25, 5, 1);

INSERT INTO skill2group VALUES (26, 7, 1);
INSERT INTO skill2group VALUES (27, 7, 1);
INSERT INTO skill2group VALUES (28, 7, 1);
INSERT INTO skill2group VALUES (29, 7, 1);
INSERT INTO skill2group VALUES (30, 7, 2);
INSERT INTO skill2group VALUES (31, 7, 2);
INSERT INTO skill2group VALUES (32, 7, 2);

INSERT INTO skill2group VALUES (33, 9, 2);
INSERT INTO skill2group VALUES (34, 9, 1);
INSERT INTO skill2group VALUES (35, 9, 2);
INSERT INTO skill2group VALUES (36, 9, 1);
INSERT INTO skill2group VALUES (37, 9, 2);
INSERT INTO skill2group VALUES (38, 9, 1);
INSERT INTO skill2group VALUES (39, 9, 1);

INSERT INTO skill2group VALUES (50, 2, 1);
INSERT INTO skill2group VALUES (51, 2, 1);
INSERT INTO skill2group VALUES (52, 2, 1);
INSERT INTO skill2group VALUES (53, 2, 2);
INSERT INTO skill2group VALUES (54, 2, 2);
INSERT INTO skill2group VALUES (55, 2, 2);
INSERT INTO skill2group VALUES (56, 2, 2);
INSERT INTO skill2group VALUES (57, 2, 2);
INSERT INTO skill2group VALUES (58, 2, 3);
INSERT INTO skill2group VALUES (59, 2, 3);
INSERT INTO skill2group VALUES (60, 2, 3);
INSERT INTO skill2group VALUES (61, 2, 3);

INSERT INTO skill2group VALUES (80, 3, 2);
INSERT INTO skill2group VALUES (81, 3, 2);
INSERT INTO skill2group VALUES (82, 3, 1);
INSERT INTO skill2group VALUES (83, 3, 1);
INSERT INTO skill2group VALUES (84, 3, 2);
INSERT INTO skill2group VALUES (85, 3, 1);
INSERT INTO skill2group VALUES (86, 3, 2);
INSERT INTO skill2group VALUES (87, 3, 1);
INSERT INTO skill2group VALUES (88, 3, 1);
INSERT INTO skill2group VALUES (89, 3, 2);
INSERT INTO skill2group VALUES (90, 3, 1);

INSERT INTO skill2group VALUES (91, 10, 1);
INSERT INTO skill2group VALUES (92, 10, 2);
INSERT INTO skill2group VALUES (93, 10, 2);
INSERT INTO skill2group VALUES (94, 10, 1);
INSERT INTO skill2group VALUES (95, 10, 1);

INSERT INTO skill2group VALUES (84, 11, 1);
INSERT INTO skill2group VALUES (96, 11, 1);
INSERT INTO skill2group VALUES (97, 11, 1);
INSERT INTO skill2group VALUES (98, 11, 2);
INSERT INTO skill2group VALUES (99, 11, 2);

INSERT INTO skill2group VALUES (100, 12, 1);
INSERT INTO skill2group VALUES (101, 12, 2);
INSERT INTO skill2group VALUES (102, 12, 2);
INSERT INTO skill2group VALUES (86, 12, 1);
INSERT INTO skill2group VALUES (95, 12, 1);

INSERT INTO skill2group VALUES (80, 13, 1);
INSERT INTO skill2group VALUES (103, 13, 2);
INSERT INTO skill2group VALUES (104, 13, 1);
INSERT INTO skill2group VALUES (105, 13, 2);
INSERT INTO skill2group VALUES (106, 13, 1);


-- SPELLS (id, name, description, evocation, range, duration)
INSERT INTO spells VALUES (1, "Assombração", "Esta magia canaliza uma quantidade de energia negativa e a vincula a um ambiente fechado (casas, torres, castelos...) fazendo com que certos mortos vivos sejam atraídos para o local. Somente mortos vivos incorpóreos (Fantasmas, Assombracoes, Sombras, Espectros...) podem ser atraídos para o local. A quantidade e o tipo de criaturas que irão assombrar o local depende da quantidade de estágios de mortos-vivos que o efeito indicar, assim o efeito de dificuldade 8 poderá atrair 4 sombras menores (3+3+3+3=12) ou em vez disso apenas um espectro maior (12=12). O evocador não tem controle sobre o tipo de criatura que sera atraída para o local (cabe ao mestre decidir quais criaturas serão atraídas para o local de acordo com o número de estágios indicado no efeito).", "ritual", "variável", "1 ano e 1 dia");
INSERT INTO spells VALUES (2, "Bola de Fogo", "Essa magia cria uma pequena bola de fogo que voa da mão do evocador em direção a um alvo escolhido. Ao se aproximar do alvo ela explode, causando um dano na área de explosão.", "instantãnea", "50 metros", "instantânea");
INSERT INTO spells VALUES (3, "Curas Físicas", "Esta magia cura instantaneamente ferimentos, reparando total ou parcialmente qualquer dano na EF do favorecido com o milagre. A quantidade de dano que é restaurada depende do Efeito utilizado.", "instantãnea", "toque", "permanente");
INSERT INTO spells VALUES (4, "Curas Heróicas", "Esse milagre recupera imediatamente a EH do ser tocado. Uma cura, que levaria horas ou dias, se faz em um instante. O processo, ainda assim, é apenas uma recuperação. Pontos de cura que levem a EH acima do máximo da criatura curada são perdidos.", "instantãnea", "toque", "instantãnea");
INSERT INTO spells VALUES (5, "Amizade", NULL, "", "", "");

-- SPELL_GROUPS (id, parent_id, name)
INSERT INTO spell_groups VALUES (1, -1, "Rastreadores");
INSERT INTO spell_groups VALUES (5, 1, "Trilha dos Caçadores");
INSERT INTO spell_groups VALUES (6, 1, "Trilha dos Exploradores");
INSERT INTO spell_groups VALUES (7, 1, "Trilha dos Guardiões");

INSERT INTO spell_groups VALUES (2, -1, "Bardos");
INSERT INTO spell_groups VALUES (8, 2, "Confraria dos Arautos");
INSERT INTO spell_groups VALUES (9, 2, "Confraria dos Artistas");
INSERT INTO spell_groups VALUES (10, 2, "Confraria dos Eruditos");

INSERT INTO spell_groups VALUES (3, -1, "Sacerdotes");
INSERT INTO spell_groups VALUES (11, 3, "Ordem de Selimon");
INSERT INTO spell_groups VALUES (12, 3, "Ordem de Sevides");
INSERT INTO spell_groups VALUES (13, 3, "Ordem de Ganis");
INSERT INTO spell_groups VALUES (14, 3, "Ordem de Parom");
INSERT INTO spell_groups VALUES (15, 3, "Ordem de Crizagom");
INSERT INTO spell_groups VALUES (16, 3, "Ordem de Crezir");
INSERT INTO spell_groups VALUES (17, 3, "Ordem de Blator");
INSERT INTO spell_groups VALUES (18, 3, "Ordem de Cruine");
INSERT INTO spell_groups VALUES (19, 3, "Ordem de Cambu");
INSERT INTO spell_groups VALUES (20, 3, "Ordem de Palier");
INSERT INTO spell_groups VALUES (21, 3, "Ordem de Plandis");
INSERT INTO spell_groups VALUES (22, 3, "Ordem de Lena");
INSERT INTO spell_groups VALUES (23, 3, "Ordem de Maira");

INSERT INTO spell_groups VALUES (4, -1, "Magos");
INSERT INTO spell_groups VALUES (24, 4, "Colégio Elemental");
INSERT INTO spell_groups VALUES (25, 4, "Colégio Necromântico");
INSERT INTO spell_groups VALUES (26, 4, "Colégio Ilusão");
INSERT INTO spell_groups VALUES (27, 4, "Colégio Naturalista");
INSERT INTO spell_groups VALUES (28, 4, "Colégio Alquímico");
INSERT INTO spell_groups VALUES (29, 4, "Colégio Conhecimento");

-- SPELL2GROUP (spell_id, spellgroup_id, cost)
-- (os valores a seguir precisam ser revistos,
--  as magias devem aparecer na ordem alfabetica)
INSERT INTO spell2group VALUES (1, 25, 1);
INSERT INTO spell2group VALUES (2, 4, 2);
INSERT INTO spell2group VALUES (2, 24, 1);
INSERT INTO spell2group VALUES (3, 3, 2);
INSERT INTO spell2group VALUES (3, 11, 1);
INSERT INTO spell2group VALUES (3, 12, 1);
INSERT INTO spell2group VALUES (3, 13, 1);
INSERT INTO spell2group VALUES (3, 22, 1);
INSERT INTO spell2group VALUES (3, 23, 1);
INSERT INTO spell2group VALUES (4, 3, 1);
INSERT INTO spell2group VALUES (4, 15, 1);
INSERT INTO spell2group VALUES (4, 16, 1);
INSERT INTO spell2group VALUES (4, 17, 1);
INSERT INTO spell2group VALUES (4, 18, 1);
INSERT INTO spell2group VALUES (4, 21, 1);
INSERT INTO spell2group VALUES (5, 2, 3);
INSERT INTO spell2group VALUES (5, 4, 2);
INSERT INTO spell2group VALUES (5, 26, 1);

-- EQUIPMENT_GROUPS (id, name)
INSERT INTO equipment_groups VALUES (1, "Animais");
INSERT INTO equipment_groups VALUES (2, "Transportes");
INSERT INTO equipment_groups VALUES (3, "Residências");
INSERT INTO equipment_groups VALUES (4, "Material Profissional");
INSERT INTO equipment_groups VALUES (5, "Miscelâneos");
INSERT INTO equipment_groups VALUES (6, "Armas");
INSERT INTO equipment_groups VALUES (7, "Defesas");

-- EQUIPMENT_COMMON (id, group_id, name, description, price, weapon, defense)
INSERT INTO equipment VALUES (1, 1, "Boi", NULL, 100, 0, 0);
INSERT INTO equipment VALUES (2, 1, "Cão comum", NULL, 50, 0, 0);
INSERT INTO equipment VALUES (6, 1, "Cavalo de guerra leve", NULL, 300, 0, 0);
INSERT INTO equipment VALUES (20, 2, "Carroça", NULL, 120, 0, 0);
INSERT INTO equipment VALUES (24, 2, "Veleiro pequeno", NULL, 200, 0, 0);
INSERT INTO equipment VALUES (40, 3, "Casa confortável", NULL, 800, 0, 0);
INSERT INTO equipment VALUES (46, 3, "Tenda", NULL, 80, 0, 0);
INSERT INTO equipment VALUES (60, 4, "Estojo para Carpinteiros", "Cola, entalhadeira, martelo, plaina, pregos, serrote pequeno.", 40, 0, 0);
INSERT INTO equipment VALUES (63, 4, "Material Completo para Trabalho em  Metais", "Bigorna, fornalha e estojo para trabalho em metais. Este conjunto não pode ser transportado.", 400, 0, 0);
INSERT INTO equipment VALUES (80, 5, "Símbolo sagrado de madeira", NULL, 1, 0, 0);
INSERT INTO equipment VALUES (104, 5, "Manto com capuz", NULL, 3, 0, 0);
INSERT INTO equipment VALUES (106, 5, "Par de luvas", NULL, 5, 0, 0);
INSERT INTO equipment VALUES (125, 5, "Fechadura complexa", NULL, 50, 0, 0);

INSERT INTO equipment VALUES (140, 6, "Arco composto", NULL, 200, 1, 0);
INSERT INTO equipment VALUES (147, 6, "Espada", NULL, 200, 1, 0);
INSERT INTO equipment VALUES (169, 6, "Punhal", NULL, 50, 1, 0);

INSERT INTO equipment VALUES (180, 7, "Couro leve", NULL, 20, 0, 1);
INSERT INTO equipment VALUES (184, 7, "Couraça metálica parcial", NULL, 1000, 0, 1);
INSERT INTO equipment VALUES (190, 7, "Escudo pequeno", NULL, 20, 1, 1);
INSERT INTO equipment VALUES (193, 7, "Elmo fechado", NULL, 50, 0, 1);

-- EQUIPMENT_WEAPONS (id, skill_id, min_strength, min_damage, l0, m0, p0, range)
INSERT INTO equipment_weapons VALUES (140, 56, -1, 5, 4, -1, -3, 200);
INSERT INTO equipment_weapons VALUES (147, 53, 0, 5, 3, 0, -3, 0);
INSERT INTO equipment_weapons VALUES (169, 51, -4, 3, 2, -2, -5, 20);
INSERT INTO equipment_weapons VALUES (190, NULL, NULL, 2, 1, -1, -3, 0);

-- EQUIPMENT_DEFENSE (id, type, base_value, absorption)
INSERT INTO equipment_defense VALUES (180, "Leve", 1, 3);
INSERT INTO equipment_defense VALUES (184, "Pesada", 1, 15);
INSERT INTO equipment_defense VALUES (190, NULL, 20, 3);
INSERT INTO equipment_defense VALUES (193, NULL, 50, 2);
