#!/usr/bin/env python
#-*- coding:utf-8 -*-

# config_dev.py
#
# Copyright (c) 2008 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import gtk
import os
from os.path import join

DATAPATH = ICONPATH = join('..', 'data')
PIXMAPSPATH = join(ICONPATH, 'pixmaps')

GTK_OK = gtk.gtk_version[1] >= 12

HOMEPATH = os.path.expanduser('~')
APPDATAPATH = join(HOMEPATH, '.taggen')
USERDBPATH = join(DATAPATH, 'user.db')
SYSDBPATH =  join(DATAPATH, 'taggen.db')

APPICON = gtk.gdk.pixbuf_new_from_file(join(ICONPATH, 'taggen.png'))

if not os.path.exists(APPDATAPATH):
    os.mkdir(APPDATAPATH)
    from shutil import copyfile
    copyfile(USERDBPATH, join(HOMEPATH, 'user.db'))

