#!/usr/bin/python
#-*- coding:utf-8 -*-

# core.py
#
# Copyright (c) 2007 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import math

COINS = 3
(
    COPPER,
    SILVER,
    GOLD
) = range(COINS)

coin_label = ['m.c.', 'm.p.', 'm.o.']

evolution_table = [10, 20, 30, 45, 60, 75, 95, 115, 135, 165, 195, 225, 265,
                   305, 345, 385, 435, 485, 535, 585, 645, 705, 765, 825, 895,
                   965, 1035, 1105, 1185, 1265, 1345, 1425, 1515, 1605, 1695,
                   1785, 1885, 1985, 2085, 2185]

def calc_eh(persona):
    persona.eh = persona.profession.eh + persona.get_fisico()
    return persona.eh

def get_level(xp):
    for i in range(len(evolution_table)):
        if xp <= evolution_table[i]:
            return i + 1

def get_xp_next(level):
    return evolution_table[level - 1] + 1

def convert_to_coins(money):
        gold = money / 100
        money = money % 100
        silver = money / 10
        copper = money % 10

        return (copper, silver, gold)

def convert_to_coins_single(money):
        if (money % 100) == 0:
            coin = GOLD
        elif (money % 10) == 0:
            coin = SILVER
        else:
            coin = COPPER

        return (money / (10 ** coin), coin)

def buy(price, coins):
    '''Argumentos: price = preco em moedas de cobre;
                   coins = dinheiro disponivel em [cobre, prata, ouro];
       Retorna:    (True se compra foi efetuada,troco)
    '''

    price_v, kind = convert_to_coins_single(price)

    if coins[kind] >= price_v:
        coins[kind] -= price_v
        deal = True

    else:
        deal = False

        conv = [0, 0, 0]
        for i in range(COINS):
            conv[i] = coins[i] * (10 ** i)

        price -= conv[kind]
        conv[kind] = 0

        for i in range(COINS):
            if conv[i] >= price:
                conv[i] -= price
                price = 0
                deal = True
            else:
                price -= conv[i]
                conv[i] = 0

        if deal:
           coins[GOLD] = conv[GOLD] / 100
           tmp = conv[GOLD] % 100
           coins[SILVER] = tmp / 10
           coins[COPPER] = tmp % 10

    return (deal, coins)

