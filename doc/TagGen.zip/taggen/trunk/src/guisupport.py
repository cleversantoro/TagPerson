#!/usr/bin/python
#-*- coding:utf-8 -*-

# guisupport.py
#
# Copyright (c) 2007 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import pygtk
pygtk.require('2.0')
import gtk
import pango
import os
from os.path import join

import core
from data import *
from value_bar import ValueBar
try:
    import config as cfg
except:
    import config_dev as cfg

(
SKILLS_COL_ID,
SKILLS_COL_NAME_GROUP,
SKILLS_COL_COST,
SKILLS_COL_LEVEL,
SKILLS_COL_BONUS,
SKILLS_COL_TOTAL,
SKILLS_COL_HAS_SPEC,
SKILLS_COL_IS_SKILL,
SKILLS_COL_UNKNOWN,
SKILLS_COL_FGCOLOR,
SKILLS_COL_BGCOLOR
) = xrange(11)

(
SPECSUGGEST_COL_SKILL_ID,
SPECSUGGEST_COL_NAME
) = xrange(2)

(
SPELLS_COL_ID,
SPELLS_COL_GROUP_ID,
SPELLS_COL_NAME_GROUP,
SPELLS_COL_COST,
SPELLS_COL_LEVEL,
SPELLS_COL_TOOLTIP,
SPELLS_COL_IS_SPELL,
SPELLS_COL_UNKNOWN,
SPELLS_COL_FGCOLOR,
SPELLS_COL_BGCOLOR
) = xrange(10)

(
EQUIP_COL_ID,
EQUIP_COL_NAME_GROUP,
EQUIP_COL_DESC,
EQUIP_COL_PRICE,
EQUIP_COL_QTD,
EQUIP_COL_IS_ITEM,
EQUIP_COL_NOTMINE,
EQUIP_COL_FGCOLOR,
EQUIP_COL_BGCOLOR
) = xrange(9)

(
PERSONA_COL_ID,
PERSONA_COL_NAME,
PERSONA_COL_RACE_ID,
PERSONA_COL_LEVEL,
PERSONA_COL_TOOLTIP,
PERSONA_COL_PIXBUF
) = xrange(6)

(
GOD_COL_ID,
GOD_COL_NAME,
GOD_COL_REALM
) = xrange(3)

PROFESSION_PIXMAPS = [
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'warrior.png')),
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'thief.png')),
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'priest.png')),
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'mage.png')),
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'ranger.png')),
    gtk.gdk.pixbuf_new_from_file(join(cfg.PIXMAPSPATH, 'bard.png'))
]

FG_COLOR = gtk.gdk.color_parse('#CCC')
BG_COLOR = {True  : gtk.gdk.color_parse('#AAA'),
            False : gtk.gdk.color_parse('#EEE')}
COLOR_BLACK = gtk.gdk.color_parse('#000')
COLOR_WHITE = gtk.gdk.color_parse('#FFF')

def init_gods(combo, gods=[]):
    model = gtk.ListStore(int, str)
    cell = gtk.CellRendererText()
    cell.set_property('ellipsize', pango.ELLIPSIZE_END)
    combo.set_model(model)
    combo.pack_start(cell, True)
    combo.add_attribute(cell, 'markup', 1)
    for god in gods:
        model.append([god[0], '<b>%s</b> <small>(%s)</small>' % \
                     (god[1], god[2])])

    return model


#TODO: mudar todos os metodos init para receber um objeto Store, em lugar de listas.
def init_players_names(completion, players=[]):
    model = gtk.ListStore(str)
    completion.set_model(model)
    completion.set_text_column(0)
    for player in players:
        model.append([player])

    return model


def init_images(wtree):
        money_image = wtree.get_widget('money_image')
        attr_image = wtree.get_widget('attr_image')
        skills_image = wtree.get_widget('skills_image')
        spells_image = wtree.get_widget('spells_image')

        money_image.set_from_file(
                join(cfg.PIXMAPSPATH, 'tagmar_dinheiro.png'))

        image = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'tagmar_atributos.png'), -1, 180)
        attr_image.set_from_pixbuf(image)

        image = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'tagmar_habilidades.png'), -1, 220)
        skills_image.set_from_pixbuf(image)

        image = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'tagmar_magia.png'), -1, -1)
        spells_image.set_from_pixbuf(image)

        attr_icon = wtree.get_widget('attributes_icon')
        skills_icon = wtree.get_widget('skills_icon')
        spells_icon = wtree.get_widget('spells_icon')
        equip_icon = wtree.get_widget('equip_icon')
        desc_icon = wtree.get_widget('description_icon')

        # Section Icons
        size = 50
        icon = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'obelisk.svg'), size, size)
        attr_icon.set_from_pixbuf(icon)

        icon = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'sword_in_the_stone.svg'), size, size)
        skills_icon.set_from_pixbuf(icon)

        icon = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'magic_stones.svg'), size, size)
        spells_icon.set_from_pixbuf(icon)

        icon = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'caravan.svg'), size, size)
        equip_icon.set_from_pixbuf(icon)

        icon = gtk.gdk.pixbuf_new_from_file_at_size(
                join(cfg.PIXMAPSPATH, 'statue.svg'), size, size)
        desc_icon.set_from_pixbuf(icon)


def init_personas(treeview, store):
    model = gtk.ListStore(int, str, int, int, str, gtk.gdk.Pixbuf)
    treeview.set_model(model)
    treeview.set_search_column(PERSONA_COL_NAME)
    if cfg.GTK_OK:
        treeview.set_tooltip_column(PERSONA_COL_TOOLTIP)

    column = gtk.TreeViewColumn('', gtk.CellRendererPixbuf(),
                                pixbuf=PERSONA_COL_PIXBUF)
    column.set_expand(False)
    treeview.append_column(column)

    column = gtk.TreeViewColumn('Personagem', gtk.CellRendererText(),
                                text=PERSONA_COL_NAME)
    column.set_expand(True)
    column.set_sort_column_id(PERSONA_COL_NAME)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Nível', renderer,
                                text=PERSONA_COL_LEVEL)
    column.set_expand(False)
    column.set_sort_column_id(PERSONA_COL_LEVEL)
    treeview.append_column(column)

    for p_id, p_name, p_race, p_prof, p_xp in store.get_persona_list():
        race_name = store.get_race_name(p_race)
        prof_name = store.get_profession_name(p_prof)
        p_level = core.get_level(p_xp)
        tooltip = '<big><b>%s</b></big>\n%s, %s, nvl %d' % \
                  (p_name, race_name, prof_name, p_level)
        model.append([p_id, p_name, p_race, p_level, tooltip,
                      PROFESSION_PIXMAPS[p_prof-1]])

    return model


def init_skills(treeview, store):
    # [id, name_group, cost, level, bonus_attribute,
    #  total, has_spec, visible, unknown, fgcolor, bgcolor]
    model = gtk.TreeStore(int, str, int, int, str, int, bool,
                          bool, bool, gtk.gdk.Color, gtk.gdk.Color)
    _filter = model.filter_new()
    treeview.set_model(_filter)

    def do_show_value(column, cell, model, iter, colnum):
        if model[iter][SKILLS_COL_IS_SKILL]:
            cell.set_property('text', str(model[iter][colnum]))
        else:
            cell.set_property('text', '')

    def do_add_skill(parent_iter, skill_id, skill_name, cost, bonus, has_spec):
        model.append(parent_iter, [skill_id, skill_name, cost, 0,
                                   ATTRIBUTE_SHORT_NAMES[bonus], 0,
                                   bool(has_spec), True, True, FG_COLOR,
                                   COLOR_WHITE])

    def do_add_group(parent_iter, group_id, group_name):
        if parent_iter is None:
            name = '<b>%s</b>' % group_name
        else:
            name = '<i>%s</i>' % group_name
        return model.append(parent_iter, [group_id, name, 0, 0, None,
                                          0, False, False, False, FG_COLOR,
                                          BG_COLOR[parent_iter is None]])

    parents = store.get_skill_group_parents()
    for group_id, group_name in parents:
        iter = do_add_group(None, group_id, group_name)

        skills = store.get_skills_from_group(group_id)
        for skill_id, skill_name, cost, bonus, has_spec in skills:
            if has_spec:
                name = '%s ...' % skill_name
            else:
                name = skill_name
            do_add_skill(iter, skill_id, name, cost, bonus, has_spec)

        subgroups = store.get_skill_group_children(group_id)
        for subgroup_id, subgroup_name in subgroups:
            iter2 = do_add_group(iter, subgroup_id, subgroup_name)

            skills = store.get_skills_from_group(subgroup_id)
            for skill_id, skill_name, cost, bonus, has_spec in skills:
                if has_spec:
                    name = '%s ...' % skill_name
                else:
                    name = skill_name
                do_add_skill(iter2, skill_id, name, cost, bonus, has_spec)

    renderer = gtk.CellRendererText()
    column = gtk.TreeViewColumn('Habilidade', renderer,
                                markup=SKILLS_COL_NAME_GROUP)
    column.add_attribute(renderer, 'cell-background-gdk', SKILLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SKILLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SKILLS_COL_FGCOLOR)
    column.set_expand(True)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Custo', renderer)
    column.set_cell_data_func(renderer, do_show_value, SKILLS_COL_COST)
    column.add_attribute(renderer, 'cell-background-gdk', SKILLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SKILLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SKILLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)


    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Nível', renderer)
    column.set_cell_data_func(renderer, do_show_value, SKILLS_COL_LEVEL)
    column.add_attribute(renderer, 'cell-background-gdk', SKILLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SKILLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SKILLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Ajuste', renderer)
    column.set_cell_data_func(renderer, do_show_value, SKILLS_COL_BONUS)
    column.add_attribute(renderer, 'cell-background-gdk', SKILLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SKILLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SKILLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Total', renderer)
    column.set_cell_data_func(renderer, do_show_value, SKILLS_COL_TOTAL)
    column.add_attribute(renderer, 'cell-background-gdk', SKILLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SKILLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SKILLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    treeview.expand_all()

    return model, _filter

def init_specializations(comboentry, completion, store):
    specs = store.get_skill_specialization_suggestions()
    # (skill_id, specialization)
    model = gtk.ListStore(int, str)
    _filter = model.filter_new()

    comboentry.set_model(_filter)
    comboentry.set_text_column(SPECSUGGEST_COL_NAME)

    completion.set_model(_filter)
    completion.set_text_column(SPECSUGGEST_COL_NAME)
    comboentry.child.set_completion(completion)

    for spec in specs:
        model.append(spec)

    return model, _filter


def init_spells(treeview, store):
    # [id, group_id, group_or_name, cost, level,
    #  tooltip, visible, unknown, fgcolor, bgcolor]
    model = gtk.TreeStore(int, int, str, int, int, str,
                          bool, bool, gtk.gdk.Color, gtk.gdk.Color)
    _filter = model.filter_new()
    treeview.set_model(_filter)

    def do_show_value(column, cell, model, iter, colnum):
        if model[iter][SPELLS_COL_IS_SPELL]:
            cell.set_property('text', str(model[iter][colnum]))
        else:
            cell.set_property('text', '')

    def do_add_spell(parent_iter, spell_id, group_id, spell, cost):
        if spell.description is None:
            tooltip = None
        else:
            tooltip = '<big><b>%s</b></big>\n<b>Evocação:</b> %s\n' \
                      '<b>Alcance:</b> %s\n<b>Duração:</b> %s\n%s' % \
                      (spell.name, spell.evocation, spell.range,
                       spell.duration, spell.description)
        model.append(parent_iter, [spell_id, group_id, spell.name, cost,
                                   0, tooltip, True, True, FG_COLOR,
                                   COLOR_WHITE])

    def do_add_group(parent_iter, group_id, group_name):
        if parent_iter is None:
            name = '<b>%s</b>' % group_name
        else:
            name = '<i>%s</i>' % group_name
        return model.append(parent_iter, [-1, group_id, name, 0, 0, None,
                                          False, False, COLOR_BLACK,
                                          BG_COLOR[parent_iter is None]])

    parents = store.get_spell_group_parents()
    for group_id, group_name in parents:
        iter = do_add_group(None, group_id, group_name)

        for spell_id, spell, cost in store.get_spells_from_group(group_id):
            do_add_spell(iter, spell_id, group_id, spell, cost)

        subgroups = store.get_spell_group_children(group_id)
        for subgroup_id, subgroup_name in subgroups:
            iter2 = do_add_group(iter, subgroup_id, subgroup_name)
            for spell_id, spell, cost in store.get_spells_from_group(subgroup_id):
                do_add_spell(iter2, spell_id, subgroup_id, spell, cost)


    renderer = gtk.CellRendererText()
    column = gtk.TreeViewColumn('Magia', renderer,
                                markup=SPELLS_COL_NAME_GROUP)
    column.add_attribute(renderer, 'cell-background-gdk', SPELLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SPELLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SPELLS_COL_FGCOLOR)
    column.set_expand(True)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Custo', renderer)
    column.set_cell_data_func(renderer, do_show_value, SPELLS_COL_COST)
    column.add_attribute(renderer, 'cell-background-gdk', SPELLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SPELLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SPELLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Nível', renderer)
    column.set_cell_data_func(renderer, do_show_value, SPELLS_COL_LEVEL)
    column.add_attribute(renderer, 'cell-background-gdk', SPELLS_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', SPELLS_COL_UNKNOWN)
    column.add_attribute(renderer, 'foreground-gdk', SPELLS_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    if cfg.GTK_OK:
        treeview.set_tooltip_column(SPELLS_COL_TOOLTIP)
    treeview.expand_all()

    return model, _filter


def init_equipment(treeview, store):
    # [id, group_or_name, desc, price, qtd, visible, notmine, FG_COLOR, BG_COLOR]
    model = gtk.TreeStore(int, str, str, int, int, bool, bool,
                          gtk.gdk.Color, gtk.gdk.Color)
    _filter = model.filter_new()
    treeview.set_model(_filter)

    def do_show_value(column, cell, model, iter, colnum):
        if model[iter][EQUIP_COL_IS_ITEM]:
            cell.set_property('text', str(model[iter][colnum]))
        else:
            cell.set_property('text', '')

    def do_format_money(column, cell, model, iter, colnum):
        if model[iter][EQUIP_COL_IS_ITEM]:
            value, coin = \
                core.convert_to_coins_single(model[iter][EQUIP_COL_PRICE])
            money_fmt = '%d %s' % (value, core.coin_label[coin])
        else:
            money_fmt = ''

        cell.set_property('text', money_fmt)

    groups = store.get_equipment_groups()
    for group_id, group_name in groups:
        iter = model.append(None, [group_id, '<b>%s</b>' % group_name,
                                   None, 0, 0, False, False,
                                   COLOR_BLACK, BG_COLOR[True]])

        equipment = store.get_equipment_from_group(group_id)
        for item_id, item_name, desc, price in equipment:
            model.append(iter, [item_id, item_name, desc,
                                price, 0, True, True,
                                FG_COLOR, COLOR_WHITE])

    renderer = gtk.CellRendererText()
    column = gtk.TreeViewColumn('Equipamento', renderer,
                                markup=EQUIP_COL_NAME_GROUP)
    column.add_attribute(renderer, 'cell-background-gdk', EQUIP_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', EQUIP_COL_NOTMINE)
    column.add_attribute(renderer, 'foreground-gdk', EQUIP_COL_FGCOLOR)
    column.set_expand(True)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 1.0)
    column = gtk.TreeViewColumn('Preço', renderer)
    column.set_cell_data_func(renderer, do_format_money, EQUIP_COL_PRICE)
    column.add_attribute(renderer, 'cell-background-gdk', EQUIP_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', EQUIP_COL_NOTMINE)
    column.add_attribute(renderer, 'foreground-gdk', EQUIP_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    renderer = gtk.CellRendererText()
    renderer.set_property('xalign', 0.5)
    column = gtk.TreeViewColumn('Qtd', renderer)
    column.set_cell_data_func(renderer, do_show_value, EQUIP_COL_QTD)
    column.add_attribute(renderer, 'cell-background-gdk', EQUIP_COL_BGCOLOR)
    column.add_attribute(renderer, 'foreground-set', EQUIP_COL_NOTMINE)
    column.add_attribute(renderer, 'foreground-gdk', EQUIP_COL_FGCOLOR)
    column.set_expand(False)
    treeview.append_column(column)

    if cfg.GTK_OK:
        treeview.set_tooltip_column(EQUIP_COL_DESC)
    treeview.expand_all()

    return model, _filter


def init_weapons(treeview):
    model = gtk.ListStore(str, str, int, int, int, int, int)
    treeview.set_model(model)
    column = gtk.TreeViewColumn('Nome', gtk.CellRendererText(), text=0)
    column.set_expand(True)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Habilidade', gtk.CellRendererText(), text=1)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Nível', gtk.CellRendererText(), text=2)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('L0', gtk.CellRendererText(), text=3)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('M0', gtk.CellRendererText(), text=4)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('P0', gtk.CellRendererText(), text=5)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Dano Máx.', gtk.CellRendererText(), text=6)
    column.set_expand(False)
    treeview.append_column(column)

    return model

def init_defence(treeview):
    model = gtk.ListStore(str, str, int, int)
    treeview.set_model(model)
    column = gtk.TreeViewColumn('Nome', gtk.CellRendererText(), text=0)
    column.set_expand(True)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Tipo', gtk.CellRendererText(), text=1)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Defesa Base', gtk.CellRendererText(), text=2)
    column.set_expand(False)
    treeview.append_column(column)
    column = gtk.TreeViewColumn('Absorção', gtk.CellRendererText(), text=3)
    column.set_expand(False)
    treeview.append_column(column)

    return model


# inicializa barras de valores -----------------------------------------------
def init_skills_value_bars(table):
    skill_pts = ValueBar(16, False)
    skill_pts.set_property('value', 2)

    weapon_pts = ValueBar(16, False)
    weapon_pts.set_property('value', 10)

    combat_pts = ValueBar(16, False)
    combat_pts.set_property('value', 15)

    table.attach(skill_pts, 0, 1, 1, 2)
    table.attach(weapon_pts, 0, 1, 3, 4)
    table.attach(combat_pts, 0, 1, 5, 6)

    return (skill_pts, combat_pts, weapon_pts)

def init_magic_value_bar(container):
    magic_pts = ValueBar(16, False)
    magic_pts.set_property('value', 2)
    container.add(magic_pts)

    return magic_pts

# inicializa tags de formatacao de texto -------------------------------------
def init_text_tags(tag_table):
    tag = gtk.TextTag('title')
    tag.set_property('pixels-below-lines', 4)
    tag.set_property('font', 'sans bold 16')
    tag.set_property('justification', gtk.JUSTIFY_CENTER)
    tag_table.add(tag)

    tag = gtk.TextTag('sub-title')
    tag.set_property('pixels-below-lines', 4)
    tag.set_property('font', 'sans bold 12')
    tag_table.add(tag)

    tag = gtk.TextTag('table-title')
    tag.set_property('weight', pango.WEIGHT_BOLD)
    tag.set_property('font', 'mono bold 10')
    tag_table.add(tag)

    tag = gtk.TextTag('table-body')
    tag.set_property('font', 'mono 10')
    tag_table.add(tag)

    tag = gtk.TextTag('bold')
    tag.set_property('weight', pango.WEIGHT_BOLD)
    tag_table.add(tag)


# Dialogs --------------------------------------------------------------------
def init_image_dialog(image_dialog):
    image_dialog.add_buttons(gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                             gtk.STOCK_OPEN, gtk.RESPONSE_OK)

    preview = gtk.Image()
    image_dialog.set_preview_widget(preview)

    imagefilter = gtk.FileFilter()
    imagefilter.set_name('Imagens')

    if os.name == 'posix': # linux
        imagefilter.add_mime_type('image/png')
        imagefilter.add_mime_type('image/jpeg')
        imagefilter.add_mime_type('image/svg+xml')
        imagefilter.add_mime_type('image/gif')
    else: # win32
        imagefilter.add_pattern('*.png')
        imagefilter.add_pattern('*.jpeg')
        imagefilter.add_pattern('*.jpg')
        imagefilter.add_pattern('*.svg')
        imagefilter.add_pattern('*.gif')

    image_dialog.add_filter(imagefilter)

    last_dir_cfg = join(cfg.APPDATAPATH, 'last_image_dir')
    if os.path.isfile(last_dir_cfg):
        f = open(last_dir_cfg, 'r')
        last_dir = f.read().strip()
        f.close()
        image_dialog.set_current_folder(last_dir)
    else:
        save_image_dir(image_dialog.get_current_folder())

    return preview

def save_image_dir(image_dir):
    last_dir_cfg = join(cfg.APPDATAPATH, 'last_image_dir')
    f = open(last_dir_cfg, 'w')
    f.write(image_dir)
    f.close()

def message(parent, message, msg_type=gtk.MESSAGE_WARNING):
    msg = gtk.MessageDialog(parent,
                            gtk.DIALOG_DESTROY_WITH_PARENT,
                            msg_type, gtk.BUTTONS_CLOSE,
                            message)
    msg.run()
    msg.destroy()

