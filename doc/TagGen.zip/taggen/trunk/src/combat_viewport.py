#!/usr/bin/python
#-*- coding:utf-8 -*-

# combat_viewport.py
#
# Copyright (c) 2008 Marcelo Lira dos Santos
#
# Author: Marcelo Lira dos Santos <setanta@gmail.com>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

import pygtk
pygtk.require('2.0')
import gtk
import gtk.glade

import data

class CombatViewport:

    def __init__(self, wtree):
        self.items = [None, None, None, None, None]

        self.viewport = wtree.get_widget('combat_viewport')
        self.viewport.modify_bg(gtk.STATE_NORMAL, gtk.gdk.color_parse('#FFF'))
        self.viewport.drag_dest_set(gtk.DEST_DEFAULT_MOTION | \
                                    gtk.DEST_DEFAULT_HIGHLIGHT | \
                                    gtk.DEST_DEFAULT_DROP,
                                    [('text/plain',
                                      gtk.TARGET_SAME_APP, 1)],
                                    gtk.gdk.ACTION_DEFAULT | \
                                    gtk.gdk.ACTION_COPY)

        self.labels = [wtree.get_widget('meleew_label'),
                       wtree.get_widget('rangedw_label'),
                       wtree.get_widget('armour_label'),
                       wtree.get_widget('helmet_label'),
                       wtree.get_widget('shield_label')]

    # Class Methods -----------------------------------------------------------
    def reset(self):
        for label in self.labels:
            label.hide()

        self.items = len(self.items) * [None]

    def has_item(self, item):
        ids = [it.id for it in self.items if it is not None]
        return item.id in ids

    def equip_item(self, item):
        item_kind = data.get_item_kind(item)

        if item_kind < 0:
            return False

        else:
            self.items[item_kind] = item
            self.labels[item_kind].set_text(item.name)
            self.labels[item_kind].show()
            self.refresh()
            return True

    def unequip_item(self, item):
        item_kind = data.get_item_kind(item)

        if item_kind < 0:
            return False

        else:
            self.items[item_kind] = None
            self.labels[item_kind].hide()
            self.refresh()
            return True

    def refresh(self):
        self.viewport.hide()
        self.viewport.show()

