#!/usr/bin/env python
# -*- coding: UTF-8 -*-

#
# TagGen - Gerador de personagens para Tagmar 2
# Copyright (C) 2007 Marcelo Lira dos Santos <setanta@gmail.com>
#
# HelloWorld! SMS is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# CLAtividades is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import os
from os.path import join
import re
from distutils.sysconfig import get_config_var
from distutils.command.install import install
from distutils.core import setup
import glob

# read the version from the taggen ChangeLog
taggen_version = os.popen('cat ChangeLog | grep -m 1 ^taggen | ' \
                                'cut -d" " -f2').read().strip()

class my_install(install):
    def run(self):
        preprocess(join('src', 'config.py.in'))
        install.run(self)

def preprocess(path):
    if os.path.exists(path):
        src = open(path, "r")
        target = open(path.strip(".in"), "w")

        lines = src.readlines()[:]

        for line in lines:
            line = re.sub("@PREFIX@", get_config_var('prefix'), line)
            line = re.sub("@VERSION@", taggen_version, line)
            target.write(line)

        target.close()
        src.close()


# files to install
data_dir      = 'data'
inst_share    = [join(data_dir, 'taggen.glade'),
                 join(data_dir, 'taggen.rc'),
                 join(data_dir, 'taggen.db')
]

pixmaps_dir   = join(data_dir, 'pixmaps')

inst_pixmaps  = [join(pixmaps_dir, f) for f in os.listdir(pixmaps_dir)
                 if f.endswith('.png')]
inst_desktop  = [join(data_dir, 'taggen.desktop')]
inst_icons    = [join(data_dir, 'taggen.png')]

data_files = [
    (join('share', 'taggen'), inst_share),
    (join('share', 'pixmaps'), inst_icons),
    (join('share', 'pixmaps', 'taggen'), inst_pixmaps),
    (join('share', 'applications'), inst_desktop),
]

setup(
    name             = 'taggen',
    version          = taggen_version,
    description      = 'Gerador de personagens para o RPG Tagmar 2.2',
    long_description = 'Gerador de personagens para o RPG Tagmar 2.2',
    author           = 'Marcelo Lira dos Santos',
    author_email     = 'setanta@gmail.com',
    url              = 'http://code.google.com/p/taggen',
    license          = 'GNU GPL v2',
    scripts          = ['src/taggen'],
    packages         = ['taggen'],
    package_dir      = {'taggen' : 'src'},
    cmdclass         = { 'install' : my_install },
    data_files       = data_files
)
