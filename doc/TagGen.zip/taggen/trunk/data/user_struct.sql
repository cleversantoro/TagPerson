CREATE TABLE persona (
    id INTEGER PRIMARY KEY,
    name VARCHAR(100) DEFAULT "",
    player VARCHAR(100) DEFAULT "",
    avatar_file VARCHAR(60) DEFAULT "",
    att_intellect INTEGER,
    att_aura INTEGER,
    att_charisma INTEGER,
    att_strength INTEGER,
    att_physical INTEGER,
    att_agility INTEGER,
    att_perception INTEGER,

    active_defense INTEGER,
    passive_defense INTEGER,
    max_eh INTEGER,
    eh INTEGER,
    ef INTEGER,
    absorption INTEGER,

    race INTEGER,
    profession INTEGER,
    specialization INTEGER,
    xp INTEGER,

    skill_points INTEGER,
    combat_points INTEGER,
    weapon_points INTEGER,
    magic_points INTEGER,

    height INTEGER,
    weight INTEGER,
    age INTEGER,

    eyes VARCHAR(60) DEFAULT "",
    hair VARCHAR(60) DEFAULT "",
    skin VARCHAR(60) DEFAULT "",
    appearance TEXT,

    god INTEGER,
    social_class INTEGER,
    place_of_origin INTEGER,
    history TEXT,
    goals TEXT,

    melee_weapon INTEGER DEFAULT -1,
    ranged_weapon INTEGER DEFAULT -1,
    armour INTEGER DEFAULT -1,
    helmet INTEGER DEFAULT -1,
    shield INTEGER DEFAULT -1,

    copper_coins INTEGER,
    silver_coins INTEGER,
    gold_coins INTEGER
);

CREATE TABLE persona_item (
    persona_id INTEGER,
    item_id INTEGER,
    qtd INTEGER,
    PRIMARY KEY (persona_id, item_id)
);

CREATE TABLE persona_spell (
    persona_id INTEGER,
    spell_id INTEGER,
    level INTEGER,
    PRIMARY KEY (persona_id, spell_id)
);

CREATE TABLE persona_skill (
    persona_id INTEGER,
    skill_id INTEGER,
    level INTEGER,
    PRIMARY KEY (persona_id, skill_id)
);

CREATE TABLE persona_skill_specialization (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    persona_id INTEGER,
    skill_id INTEGER,
    specialization VARCHAR(40) DEFAULT "",
    level INTEGER
);
