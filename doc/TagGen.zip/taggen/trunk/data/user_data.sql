-- PERSONA (id, name, player, avatar_file, att_intellect, att_aura, att_charisma,
--          att_strength, att_physical, att_agility, att_perception,
--          active_defense, passive_defense, max_eh, eh, ef, absorption,
--          race, profession, specialization, xp, skill_points,
--          combat_points, weapon_points, magic_points, height, weight, age,
--          eyes, hair, skin, appearance, god, social_class, place_of_origin,
--          history, goals, melee_weapon, ranged_weapon, armour, helmet, shield,
--          copper_coins, silver_coins, gold_coins)
-- PERSONA_SPELL (persona_id, spell_id, level)
-- PERSONA_ITEM (persona_id, item_id, qtd)
-- PERSONA_SKILL (persona_id, skill_id, level)
-- PERSONA_SKILL_ITEM (id, persona_id, skill_id, specialization, level)
INSERT INTO persona (id, name, race, profession, xp) VALUES (1, "Rosencrantz", 1, 6, 4);
INSERT INTO persona (id, name, race, profession, xp) VALUES (2, "Guildenstern", 1, 2, 4);
INSERT INTO persona (id, name, race, profession, xp) VALUES (3, "Odin", 1, 1, 1);
INSERT INTO persona (id, name, race, profession, xp) VALUES (4, "Myau", 5, 4, 1);
INSERT INTO persona (id, name, race, profession, xp) VALUES (5, "Noah", 2, 3, 2);
INSERT INTO persona (id, name, race, profession, xp) VALUES (6, "Alis", 3, 5, 1);
INSERT INTO persona (id, name, race, profession, xp) VALUES (7, "Thorin", 3, 1, 5);

INSERT INTO persona VALUES (8, "Tanagrim", "", NULL, 1, 1, 2, 3, 3, 2, 1, 6, 5, 19, 19, 12, 20, 1, 1, 2, 1, 14, 7, 7, 0, 185, 80, 26, 'pretos', 'preto', 'clara', 'Bruto.', 1, 2, 2, 'Saiu por aí até chegar lá.', 'Qualquer coisa', -1, -1, -1, -1, -1, 8, 4, 1);
INSERT INTO persona_item VALUES (8, 147, 1);
INSERT INTO persona_item VALUES (8, 180, 1);
INSERT INTO persona_item VALUES (8, 190, 1);
INSERT INTO persona_skill VALUES (8, 1, 1);
INSERT INTO persona_skill VALUES (8, 53, 1);
INSERT INTO persona_skill VALUES (8, 54, 1);
INSERT INTO persona_skill VALUES (8, 55, 1);

INSERT INTO persona VALUES (9, "Timothy", "", NULL, 2, 3, 1, 0, 0, 1, 1, 6, 5, 6, 6, 12, 16, 1, 4, 22, 1, 12, 5, 4, 7, 177, 72, 17, 'pretos', 'preto', 'clara', 'Franzino.', 16, 2, 1, 'Estuda as artes mágicas.', 'Ser o mais fodao.', -1, -1, -1, -1, -1, 27, 18, 5);
INSERT INTO persona_spell VALUES (9, 1, 1);
INSERT INTO persona_spell VALUES (9, 2, 1);
INSERT INTO persona_spell VALUES (9, 3, 1);
INSERT INTO persona_item VALUES (9, 104, 1);
INSERT INTO persona_item VALUES (9, 106, 1);
INSERT INTO persona_item VALUES (9, 169, 2);
INSERT INTO persona_skill VALUES (9, 1, 1);
INSERT INTO persona_skill VALUES (9, 2, 1);
INSERT INTO persona_skill VALUES (9, 53, 1);

INSERT INTO persona_skill VALUES (9, 13, 0);
INSERT INTO persona_skill_specialization (persona_id, skill_id, specialization, level) VALUES (9, 13, "Comum", 1);
INSERT INTO persona_skill_specialization (persona_id, skill_id, specialization, level) VALUES (9, 13, "Élfico", 1);
