#!/usr/bin/python
#-*- coding:utf-8 -*-

from os import path
import gtk
import gtk.glade
import pango

import data
import xmlreader
from areas import Areas

class TagMap( object ):
	def __init__( self ):
		self.marks = []
		self.place = None
		self.bullet = gtk.gdk.pixbuf_new_from_file(path.join('ui', 'bullet.png'))
		self.banner = gtk.gdk.pixbuf_new_from_file(path.join('ui', 'banner.png'))
		mapfile, \
		self.groundzero, \
		self.scale, \
		self.atlas = xmlreader.load_atlas(path.join('data', 'atlas.xml'))
		self.areas = Areas(self.groundzero, self.scale)
		self.zoom = 1.0

		#debug
		self.marks.append(self.groundzero)
		self.marks = []

		for key in self.atlas.keys():
			self.areas.add_area(key, self.atlas[key].area)

		self.wTree = gtk.glade.XML(path.join('ui', 'tagmap.glade'))

		self.mapWindow = self.wTree.get_widget('tmWindow')
		self.mapWindow.set_icon_from_file(path.join('ui', 'tagmap-icon.png'))
		
		self.status = self.wTree.get_widget('statusbar')
		self.id = self.status.get_context_id('status')
		
		self.mapMenu = self.wTree.get_widget('mapMenu')
		
		self.zoomInBtn = self.wTree.get_widget('zoomInBtn')
		self.zoomOutBtn = self.wTree.get_widget('zoomOutBtn')
		self.zoomInBtn.set_sensitive(False)

		self.textScrolledWindow = self.wTree.get_widget('textScrolledWindow')
		self.mapVp = self.wTree.get_widget('mapViewport')
		self.mapImg = self.wTree.get_widget('mapImage')

		self.map_pixbuf_orig = gtk.gdk.pixbuf_new_from_file(path.join('data', mapfile))
		self.map_pixbuf = self.map_pixbuf_orig
		self.map_width = self.map_pixbuf_orig.props.width
		self.map_pixmap = gtk.gdk.Pixmap(None,
													self.map_width,
													self.map_pixbuf.props.height, 24)

		self.gc = self.map_pixmap.new_gc()
		self.gc.foreground = gtk.gdk.color_parse('red')
		self.gc.set_line_attributes(2, gtk.gdk.LINE_SOLID,
												gtk.gdk.CAP_ROUND,
												gtk.gdk.JOIN_ROUND)
		
		self.textBuffer = gtk.TextBuffer(None)
		self.wTree.get_widget('descrView').set_buffer(self.textBuffer)
		tag_table = self.textBuffer.get_tag_table()
		
		# Text Tags -----------------------------------
		title_tag = gtk.TextTag('title1')
		title_tag.set_property('pixels-below-lines', 4)
		title_tag.set_property('font', 'sans bold 18')
		title_tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(title_tag)
		
		title_tag = gtk.TextTag('title2')
		title_tag.set_property('pixels-below-lines', 4)
		title_tag.set_property('font', 'sans bold 13')
		title_tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(title_tag)

		quote_tag = gtk.TextTag('quote')
		quote_tag.set_property('pixels-below-lines', 4)
		quote_tag.set_property('font', 'sans 11')
		quote_tag.set_property('style', pango.STYLE_ITALIC)
		tag_table.add(quote_tag)
		
		author_tag = gtk.TextTag('author')
		author_tag.set_property('pixels-below-lines', 4)
		author_tag.set_property('font', 'sans 11')
		author_tag.set_property('justification', gtk.JUSTIFY_RIGHT)
		tag_table.add(author_tag)
		
		center_tag = gtk.TextTag('center')
		center_tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(center_tag)
		
		#GDK Events
		#Pointer Motion | Button 1 Motion | Button Release | Structure
		self.mapWindow.connect('destroy', gtk.main_quit)
		self.mapVp.connect('motion-notify-event', self.motion)

		self.wTree.signal_autoconnect(self)

		self.draw_map()
		
	# Callbacks ----------------------------------------------------------------
	def motion(self, widget, event):
		coord = event.get_coords()
		border = (self.mapVp.allocation.width - self.map_width) / 2
		if border > 0:
			coord = (coord[0] - border, coord[1]) 
		coords = self.areas.revert_point(coord)
		self.place = self.areas.inside_area(coords)
		if self.place:
			self.status.push(self.id, self.place)
		else:
			self.place = None
			self.status.push(self.id, str(coords))
		
	def press(self, widget, event):
		if event.type == gtk.gdk._2BUTTON_PRESS:
			coord = tuple([int(n) for n in event.get_coords()])
			border = (self.mapVp.allocation.width - self.map_width) / 2
			if border > 0:
				coord = (coord[0] - border, coord[1])
			self.marks.append(coord)
			self.draw_map()
		elif event.type == gtk.gdk.BUTTON_PRESS:
			if event.button == 3:
				self.mapMenu.popup(None, None, None, event.button, event.time)
			else:
				self.show_site()

	def zoom_in(self, widget):
		if self.zoom < 1.00:
			self.zoom = self.zoom * 2.0

			if self.zoom == 1.00:
				self.zoomInBtn.set_sensitive(False)
			elif self.zoom == 0.5:
				self.zoomOutBtn.set_sensitive(True)
				
			self.areas.scale = self.areas.scale * 2.0
			self.areas.groundzero = tuple([n * 2 for n in self.areas.groundzero])
			
			self.resize_marks(2.0)
			self.resize_map()
		
	def zoom_out(self, widget):
		if self.zoom > 0.25:
			self.zoom = self.zoom * 0.5

			if self.zoom == 0.25:
				self.zoomOutBtn.set_sensitive(False)
			elif self.zoom == 0.5:
				self.zoomInBtn.set_sensitive(True)
				
			self.areas.scale = self.areas.scale * 0.5
			self.areas.groundzero = tuple([n / 2 for n in self.areas.groundzero])

			self.resize_marks(0.5)
			self.resize_map()
		
	def zoom_normal(self, widget):
		if self.zoom != 1.0:
			self.zoomOutBtn.set_sensitive(True)
			self.zoomInBtn.set_sensitive(False)
			self.areas.groundzero = self.groundzero
			self.areas.scale = self.scale
			self.resize_marks(1.0 / self.zoom)
			self.zoom = 1.0
			self.resize_map()

	def clear_marks(self, widget):
		#debug
		print
		for mark in self.marks: print '<coordenadas x="%d" y="%d"/>' % \
						self.areas.revert_point(mark)

		if self.marks:
			self.marks = []
			self.status.push(self.id, '')
			self.draw_map()
		
	def remove_last_mark(self, widget):
		if self.marks:
			self.marks.pop()
			self.draw_map()

	def show_info(self, widget):
		self.show_site()
		
	# Support Functions --------------------------------------------------------
	def show_site(self):
		try:
			site = self.atlas[self.place]
		except:
			return
		
		self.textScrolledWindow.get_vadjustment().set_value(0)
		self.textBuffer.set_text('')
		self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																'%s\n' % site.name, 'title1')

		if site.image:
			self.textBuffer.insert_pixbuf(self.textBuffer.get_end_iter(),
					gtk.gdk.pixbuf_new_from_file(path.join('data', site.image)))
	
		is_kingdom = site.type == data.Kingdom
		if is_kingdom and site.quote:
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																'\n\n"%s"\n' % site.quote[0],
																'quote')
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																site.quote[1],
																'author')
			self.textBuffer.insert_at_cursor('\n\n')
			
		if site.description:
			self.textBuffer.insert_at_cursor(' %s\n' % site.description)
			
		if is_kingdom and site.cities:
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																	'Cidades & Locais', 'title2')
			self.textBuffer.insert_at_cursor('\n\n')
			for city in site.cities:
				self.textBuffer.insert_at_cursor('   ')
				self.textBuffer.insert_pixbuf(self.textBuffer.get_end_iter(),
														self.bullet)
				self.textBuffer.insert_at_cursor(' %s\n' % city)

	def draw_map(self):
		self.map_pixmap.draw_pixbuf(None, self.map_pixbuf, 0, 0, 0, 0,
												self.map_pixbuf.props.width,
												self.map_pixbuf.props.height,
												gtk.gdk.RGB_DITHER_NORMAL,
												0, 0)
		#debug
		self.debug_draw_bonds()

		if len(self.marks) > 1:
			self.map_pixmap.draw_lines(self.gc, self.marks)
			self.status.push(self.id, 'Distância: %.2f km' %
									self.areas.calc_distance(self.marks))

		width = self.banner.props.width
		height = self.banner.props.height
		for coord in self.marks:
			#print coord
			x = int(coord[0] - 2)
			y = int(coord[1] - height)
			self.map_pixmap.draw_pixbuf(None, self.banner, 0, 0, x, y,
													width, height, gtk.gdk.RGB_DITHER_NORMAL,
													0, 0)

		self.mapImg.set_from_pixmap(self.map_pixmap, None)

	def resize_marks(self, zoom):
		marks = []
		for mark in self.marks:
			marks.append((int(mark[0] * zoom), int(mark[1] * zoom)))
		self.marks = marks

	def resize_map(self):
		if self.zoom == 1.0:
			self.map_pixbuf = self.map_pixbuf_orig
		else:
			width = int(self.map_pixbuf_orig.get_width() * self.zoom)
			height = int(self.map_pixbuf_orig.get_height() * self.zoom)
			self.map_pixbuf = self.map_pixbuf_orig.scale_simple(width, height,
																	gtk.gdk.INTERP_BILINEAR)

		self.map_width = self.map_pixbuf.props.width
		self.map_pixmap = gtk.gdk.Pixmap(None,
													self.map_width,
													self.map_pixbuf.props.height, 24)
		self.draw_map()

	def debug_draw_bonds(self):
		for polygon in self.areas.get_polygons():
			self.map_pixmap.draw_lines(self.gc, polygon[1])
		for circle in self.areas.get_circles():
			circ = circle[1]
			self.map_pixmap.draw_arc(self.gc, False,
												circ[0] - circ[2], circ[1] - circ[2],
												circ[2] * 2, circ[2] * 2,
												0, 64 * 360)


if __name__ == '__main__':
	TagMap()
	gtk.main()
