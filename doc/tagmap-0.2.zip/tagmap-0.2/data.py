#!/usr/bin/python
#-*- coding:utf-8 -*-

class Site:
	CIRCLE = 0
	POLYGON = 1
		
	def __init__(self, name=None, description=None):
		self.type = Site
		self.name = name
		self.image = None
		self.description = description
		self.areaType = Site.CIRCLE
		self.area = None

	def set_area(self, areaType, area):
		self.areaType = areaType
		self.area = area


class Kingdom (Site):
	def __init__(self, name=None):
		Site.__init__(self, name)
		self.type = Kingdom
		self.quote = None
		self.cities = []

		
if __name__ == '__main__':
	k = Kingdom('Calco')
	k.description = 'Reino em algum lugar de Tagmar.'
	print k.name
	print k.description
