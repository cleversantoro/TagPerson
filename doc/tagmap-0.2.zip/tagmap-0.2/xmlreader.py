#!/usr/bin/python
#-*- coding:utf-8 -*-

from data import Site
from data import Kingdom
import xml.dom.minidom as minidom

def load_atlas(filename='atlas.xml'):
	doc = minidom.parse(filename)
	
	sites = {}

	mapfile = doc.childNodes[0].getAttribute('imagem')
	scale = float(doc.childNodes[0].getAttribute('escala'))

	center_node = doc.childNodes[0].getElementsByTagName('marcozero')[0]
	center = (int(center_node.getAttribute('x')),
					int(center_node.getAttribute('y')))

	for site in doc.childNodes[0].getElementsByTagName('sitio'):
		proc_site = process_site(site)
		if proc_site:
			sites[proc_site.name] = proc_site
				
	return (mapfile, center, scale, sites)

def process_site(site):
	if site.getAttribute('tipo') == 'reino':
		return process_kingdom(site)
	else:
		return process_region(site)

def process_kingdom(site):
	kingdom = Kingdom(site.getAttribute('nome'))

	image = site.getAttribute('imagem')
	if image:
		kingdom.image = image

	quote = site.getElementsByTagName('citacao')
	if quote:
		quote = quote[0]
		kingdom.quote = (quote.childNodes[0].nodeValue.encode('utf-8').strip(),
								quote.getAttribute('autor'))

	node_descr = site.getElementsByTagName('descricao')
	if node_descr:
		kingdom.description = node_descr[0].\
										childNodes[0].nodeValue.encode('utf-8').strip()

	cities = site.getElementsByTagName('cidades')
	if cities:
		process_cities(cities[0], kingdom.cities)
	kingdom.areaType, kingdom.area = \
							process_area(site.getElementsByTagName('area')[0])

	return kingdom
	
def process_region(site):
	region = Site(site.getAttribute('nome'))

	image = site.getAttribute('imagem')
	if image:
		region.image = image

	node_descr = site.getElementsByTagName('descricao')
	if node_descr:
		region.description = node_descr[0].\
									childNodes[0].nodeValue.encode('utf-8').strip()

	region.areaType, region.area = \
							process_area(site.getElementsByTagName('area')[0])

	return region

def process_cities(cities_node, cities):
	if cities_node:
		for city in cities_node.childNodes:
			if city.nodeType == city.ELEMENT_NODE:
				cities.append(city.getAttribute('nome'))

def process_area(area_node):
	if area_node:
		tipo = area_node.getAttribute('tipo')
		if tipo == 'circulo':
			areaType = Site.CIRCLE
			coord = area_node.getElementsByTagName('coordenadas')[0]
			coords = (int(coord.getAttribute('x')),
							int(coord.getAttribute('y')),
							int(coord.getAttribute('raio')))
		elif tipo == 'ponto':
			areaType = Site.CIRCLE
			coord = area_node.getElementsByTagName('coordenadas')[0]
			coords = (int(coord.getAttribute('x')), int(coord.getAttribute('y')), 4)
		else:
			areaType = Site.POLYGON
			coords = []
			for coord in area_node.getElementsByTagName('coordenadas'):
				coords.append((int(coord.getAttribute('x')),
									int(coord.getAttribute('y'))))
			coords.append(coords[0])
			coords = tuple(coords)

	return (areaType, coords)

if __name__ == '__main__':
	sites = load_atlas('data/atlas.xml')
	
	for name in sites.keys():
		site = sites[name]

		print site.name
		print site.image
		print site.description
		if type(site) == type(Kingdom):
			print site.quote
			print site.cities
		print site.areaType
		print site.area
		print '\n'
		
	print sites.keys()
