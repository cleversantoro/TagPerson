#!/usr/bin/python
#-*- coding:utf-8 -*-

from os import path
import gc
import gtk
import gtk.glade
import gobject
import pango

import data
import xmlreader
from areas import Areas
import tagmap_globals as tg

class TagMap( object ):
	def __init__( self ):
		self.marks = []
		self.place = None
		self.bullet = gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'bullet.png'))
		self.banner = gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'banner.png'))
		mapfile, \
		self.groundzero, \
		self.scale, \
		self.atlas = xmlreader.load_atlas(path.join(tg.data_dir, 'atlas.xml'))
		self.areas = Areas(self.groundzero, self.scale)
		self.zoom = 1.0
		
		self.change_cursor = None
		
		self.debug = False

		#pointer
		self.pointer = None
		self.pointer_timeout = 208
		self.pointer_raio = 20
		self.pointer_counter = -1
		self.timeout = None

		#debug
		#self.marks.append(self.groundzero)
		#debug

		for key in self.atlas.keys():
			self.areas.add_area(key, self.atlas[key].area)

		# Glade ---------------------------------------
		wTree = gtk.glade.XML(path.join(tg.glade_dir, 'tagmap.glade'))

		self.mapWindow = wTree.get_widget('tmWindow')
		self.mapWindow.set_icon_from_file(path.join(tg.glade_dir, 'tagmap-icon.png'))
		self.about = wTree.get_widget('tagmapAbout')

		self.status = wTree.get_widget('statusbar')
		self.id = self.status.get_context_id('status')

		self.mapMenu = wTree.get_widget('mapMenu')
		self.notebook = wTree.get_widget('notebook')
		self.searchEntry = wTree.get_widget('searchEntry')
		
		self.zoomInBtn = wTree.get_widget('zoomInBtn')
		self.zoomOutBtn = wTree.get_widget('zoomOutBtn')

		self.textScrolledWindow = wTree.get_widget('textScrolledWindow')
		self.mapVp = wTree.get_widget('mapViewport')
		self.mapImg = wTree.get_widget('mapImage')

		self.map_pixbuf_orig = gtk.gdk.pixbuf_new_from_file(path.join(tg.data_dir, mapfile))
		self.map_pixbuf = self.map_pixbuf_orig
		self.map_width = self.map_pixbuf_orig.props.width
		self.map_height = self.map_pixbuf_orig.props.height

		self.map_pixmap = gtk.gdk.Pixmap(None, self.map_width,
													self.map_pixbuf.props.height,
													gtk.gdk.visual_get_system().depth)

		self.gc = self.map_pixmap.new_gc()
		cmap = self.map_pixmap.get_colormap()
		self.gc.foreground = cmap.alloc_color('red')
		self.gc.set_line_attributes(2, gtk.gdk.LINE_SOLID,
												gtk.gdk.CAP_ROUND,
												gtk.gdk.JOIN_ROUND)

		# TreeView ------------------------------------
		searchList = wTree.get_widget('searchList')

		column = gtk.TreeViewColumn('', gtk.CellRendererPixbuf(), pixbuf=0)
		searchList.append_column(column)
		column = gtk.TreeViewColumn('Local', gtk.CellRendererText(), text=1)
		searchList.append_column(column)
		self.icons = [gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'place.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'city.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'kingdom.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'region.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'forest.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'mountain.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'water.png')),
							gtk.gdk.pixbuf_new_from_file(path.join(tg.glade_dir, 'island.png'))]
		
		
		self.searchList = gtk.ListStore(gtk.gdk.Pixbuf, str)
		self.searchFilter = self.searchList.filter_new()
		self.searchFilter.set_visible_func(self.searchVisible, data=None)
		searchList.set_model(self.searchFilter)

		'''
		places = []
		for key in self.atlas.keys():
			#if self.atlas[key].type == data.City:
			places.append(key)
			print self.atlas.keys
		places.sort()
		for place in places:
			self.searchList.append([self.icons[0], place])
		'''
	
		for key in self.atlas.keys():
			self.searchList.append([self.icons[self.atlas[key].type], key])


		self.textBuffer = gtk.TextBuffer(None)
		self.descrView = wTree.get_widget('descrView')
		self.descrView.set_buffer(self.textBuffer)

		# Text Tags -----------------------------------
		tag_table = self.textBuffer.get_tag_table()

		tag = gtk.TextTag('title1')
		tag.set_property('pixels-below-lines', 4)
		tag.set_property('font', 'sans bold 18')
		tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(tag)
		
		tag = gtk.TextTag('title2')
		tag.set_property('pixels-below-lines', 4)
		tag.set_property('font', 'sans bold 13')
		tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(tag)
		
		tag = gtk.TextTag('link')
		tag.set_property('weight', pango.WEIGHT_BOLD)
		tag.connect('event', self.hyperlink_handler)
		tag_table.add(tag)

		tag = gtk.TextTag('quote')
		tag.set_property('pixels-below-lines', 4)
		tag.set_property('font', 'sans 11')
		tag.set_property('style', pango.STYLE_ITALIC)
		tag_table.add(tag)
		
		tag = gtk.TextTag('author')
		tag.set_property('pixels-below-lines', 4)
		tag.set_property('font', 'sans 11')
		tag.set_property('justification', gtk.JUSTIFY_RIGHT)
		tag_table.add(tag)
		
		tag = gtk.TextTag('center')
		tag.set_property('justification', gtk.JUSTIFY_CENTER)
		tag_table.add(tag)
		
		#GDK Events
		#Pointer Motion | Button 1 Motion | Button Release | Structure
		self.mapWindow.connect('destroy', gtk.main_quit)
		self.mapVp.connect('motion-notify-event', self.motion)

		wTree.signal_autoconnect(self)

		self.draw_map()

	# Callbacks ----------------------------------------------------------------
	def quit(self, widget):
		gtk.main_quit()
		
	def debug_switch(self, widget):
		self.debug = not self.debug

	def show_about(self, widget):
		self.about.show()

	def hide_about(self, widget, event):
		self.about.hide()
		return True

	def motion(self, widget, event):
		coord = event.get_coords()
		border = (self.mapVp.allocation.width - self.map_width) / 2
		if border > 0:
			coord = (coord[0] - border, coord[1])
		coords = self.areas.revert_point(coord)
		self.place = self.areas.inside_area(coords)
		if self.place:
			self.status.push(self.id, self.place)
		elif self.debug:
			self.status.push(self.id, str(coords))
	
	def press(self, widget, event):
		if event.type == gtk.gdk._2BUTTON_PRESS:
			coord = tuple([int(n) for n in event.get_coords()])
			border = (self.mapVp.allocation.width - self.map_width) / 2
			if border > 0:
				coord = (coord[0] - border, coord[1])
			self.marks.append(coord)
			self.draw_map()
		elif event.type == gtk.gdk.BUTTON_PRESS:
			if event.button == 3:
				self.mapMenu.popup(None, None, None, event.button, event.time)
			else:
				self.notebook.set_current_page(1)
				self.show_site()

	def search_changed(self, widget):
		self.searchFilter.refilter()

	def searchitem_selected(self, widget, path, column):
		self.place = self.searchFilter.get_value(self.searchFilter.get_iter(path), 1)
		self.goto_place(self.place)

	def hyperlink_handler(self, texttag, widget, event, iter):
		if event.type == gtk.gdk.BUTTON_PRESS:
			begin = iter.copy()
			while not begin.begins_tag(texttag):
				begin.backward_char()

			end = iter.copy()
			while not end.ends_tag(texttag):
				end.forward_char()

			self.place = self.textBuffer.get_text(begin, end).decode('utf-8').strip()
			
			self.goto_place(self.place)
			self.notebook.set_current_page(1)
		
			
	def textview_motion (self, widget, event):
		'''change the cursor to a hand when we are over a mail or an url'''
		pointer_x, pointer_y, spam = self.window.get_pointer()
		x, y = self.window_to_buffer_coords(gtk.TEXT_WINDOW_TEXT, pointer_x,
			pointer_y)
		tags = self.get_iter_at_location(x, y).get_tags()
		if self.change_cursor:
			self.get_window(gtk.TEXT_WINDOW_TEXT).set_cursor(
				gtk.gdk.Cursor(gtk.gdk.XTERM))
			self.change_cursor = None
		tag_table = self.get_buffer().get_tag_table()
		over_line = False
		for tag in tags:
			if tag in (tag_table.lookup('url'), tag_table.lookup('mail')):
				self.get_window(gtk.TEXT_WINDOW_TEXT).set_cursor(
					gtk.gdk.Cursor(gtk.gdk.HAND2))
				self.change_cursor = tag
			elif tag == tag_table.lookup('focus-out-line'):
				over_line = True


	def zoom_in(self, widget):
		if self.zoom < 2.0:
			self.zoom = self.zoom * 2.0

			if self.zoom == 2.0:
				self.zoomInBtn.set_sensitive(False)
			self.zoomOutBtn.set_sensitive(True)

			self.areas.scale = self.areas.scale * 2.0
			self.areas.groundzero = tuple([n * 2 for n in self.areas.groundzero])

			self.resize_marks(2.0)
			self.resize_map(2.0)

	def zoom_out(self, widget):
		if self.zoom > 0.25:
			self.zoom = self.zoom * 0.5

			if self.zoom == 0.25:
				self.zoomOutBtn.set_sensitive(False)
			self.zoomInBtn.set_sensitive(True)
				
				
			self.areas.scale = self.areas.scale * 0.5
			self.areas.groundzero = tuple([n / 2 for n in self.areas.groundzero])

			self.resize_marks(0.5)
			self.resize_map(0.5)
		
	def zoom_normal(self, widget):
		if self.zoom != 1.0:
			zoom_factor = 1.0 / self.zoom
			self.zoomOutBtn.set_sensitive(True)
			self.zoomInBtn.set_sensitive(True)
			self.areas.groundzero = self.groundzero
			self.areas.scale = self.scale
			self.resize_marks(1.0 / self.zoom)
			self.zoom = 1.0
			self.resize_map(zoom_factor)

	def clear_marks(self, widget):
		#debug
		print
		for mark in self.marks: print '<coordenadas x="%d" y="%d"/>' % \
						self.areas.revert_point(mark)
		#debug

		if self.marks:
			self.marks = []
			self.status.push(self.id, '')
			self.draw_map()
		
	def remove_last_mark(self, widget):
		if self.marks:
			self.marks.pop()
			self.draw_map()

	def show_info(self, widget):
		self.show_site()
		
	# Support Functions --------------------------------------------------------
	def show_site(self):
		try:
			site = self.atlas[self.place]
		except:
			return
			
		self.textScrolledWindow.get_vadjustment().set_value(0)
		self.textBuffer.set_text('')
		self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																'%s\n' % site.name, 'title1')

		if site.image:
			self.textBuffer.insert_pixbuf(self.textBuffer.get_end_iter(),
					gtk.gdk.pixbuf_new_from_file(path.join(tg.data_dir, site.image)))
	
		if site.quote:
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																'\n\n"%s"\n' % site.quote[0],
																'quote')
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																site.quote[1],
																'author')
			self.textBuffer.insert_at_cursor('\n\n')
			
		if site.description:
			self.textBuffer.insert_at_cursor(' %s\n' % site.description)
			
		if site.type == site.KINGDOM and site.cities:
			self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																	'Cidades & Locais', 'title2')
			self.textBuffer.insert_at_cursor('\n\n')
			for city in site.cities:
				self.textBuffer.insert_at_cursor('   ')
				self.textBuffer.insert_pixbuf(self.textBuffer.get_end_iter(),
														self.bullet)
				self.textBuffer.insert_with_tags_by_name(self.textBuffer.get_end_iter(),
																	' %s\n' % city.name, 'link')

	def goto_place(self, place):
		place = self.atlas[self.place]
		blink = (place.areaType == place.CIRCLE)
		if blink:
			coord = place.area[:2]
		else:
			coord = self.areas.calc_polygon_center(place.area)
		blink = blink and (place.type == place.CITY or place.type == place.PLACE)

		x, y = self.areas.adjust_coord(coord)
		width = self.mapVp.allocation.width
		height = self.mapVp.allocation.height
		a = x - int(width / 2)
		b = y - int(height / 2)
		max_horiz = self.map_width - width
		max_vert = self.map_height - height
		if a < 0:
			a = 0
		elif a > max_horiz:
			a = max_horiz
		if b < 0:
			b = 0
		elif b > max_vert:
			b = max_vert

		if self.timeout:
			gobject.source_remove(self.timeout)

		self.pointer = (x, y)
		self.pointer_counter = 6

		self.mapVp.get_hadjustment().set_value(a)
		self.mapVp.get_vadjustment().set_value(b)
		self.show_site()
		
		if blink:
			self.timeout = gobject.timeout_add(self.pointer_timeout, self.draw_pointer)


	def searchVisible(self, model, iter, user_data):
		search = self.searchEntry.get_text()
		if not search.strip():
			return True
		return search.upper() in model.get_value(iter, 1).upper()
		
	def draw_pointer(self):
		if self.pointer_counter > 0:
			self.timeout = gobject.timeout_add(self.pointer_timeout, self.draw_pointer)
			self.draw_map()
		self.pointer_counter -= 1


	def draw_map(self):
		self.map_pixmap.draw_pixbuf(None, self.map_pixbuf, 0, 0, 0, 0,
												self.map_pixbuf.props.width,
												self.map_pixbuf.props.height,
												gtk.gdk.RGB_DITHER_NORMAL,
												0, 0)
		#debug
		if self.debug:
			self.debug_draw_bonds()
		#debug

		if not self.pointer_counter % 2:
			raio = int(self.pointer_raio * self.zoom)
			self.map_pixmap.draw_arc(self.gc, False,
											self.pointer[0] - raio,
											self.pointer[1] - raio,
											raio * 2, raio * 2,
											0, 64 * 360)

		if len(self.marks) > 1:
			self.map_pixmap.draw_lines(self.gc, self.marks)
			self.status.push(self.id, 'Distância: %.2f km' %
									(self.areas.calc_distance(self.marks) / self.zoom))

		width = self.banner.props.width
		height = self.banner.props.height
		for coord in self.marks:
			x = int(coord[0] - 2)
			y = int(coord[1] - height)
			self.map_pixmap.draw_pixbuf(None, self.banner, 0, 0, x, y,
													width, height, gtk.gdk.RGB_DITHER_NORMAL,
													0, 0)

		self.mapImg.set_from_pixmap(self.map_pixmap, None)

	def resize_marks(self, zoom):
		marks = []
		for mark in self.marks:
			marks.append((int(mark[0] * zoom), int(mark[1] * zoom)))
		self.marks = marks

	def resize_map(self, zoom_factor):
		half_width = int(self.mapVp.allocation.width / 2)
		half_height = int(self.mapVp.allocation.height / 2)
		x = self.mapVp.get_hadjustment().get_value() + half_width
		y = self.mapVp.get_vadjustment().get_value() + half_height
		
		if self.zoom == 1.0:
			self.map_pixbuf = self.map_pixbuf_orig
		else:
			width = int(self.map_pixbuf_orig.get_width() * self.zoom)
			height = int(self.map_pixbuf_orig.get_height() * self.zoom)
			self.map_pixbuf = self.map_pixbuf_orig.scale_simple(width, height,
																	gtk.gdk.INTERP_BILINEAR)

		self.map_width = self.map_pixbuf.props.width
		self.map_height = self.map_pixbuf.props.height
		self.map_pixmap = gtk.gdk.Pixmap(None,
													self.map_width,
													self.map_pixbuf.props.height,
													gtk.gdk.visual_get_system().depth)

		self.draw_map()
		gc.collect()
		
		x = int(x * zoom_factor) - half_width
		y = int(y * zoom_factor) - half_height
		self.mapVp.get_hadjustment().set_value(x)
		self.mapVp.get_vadjustment().set_value(y)

	def debug_draw_bonds(self):
		for polygon in self.areas.get_polygons():
			self.map_pixmap.draw_lines(self.gc, polygon[1])
		for circle in self.areas.get_circles():
			circ = circle[1]
			self.map_pixmap.draw_arc(self.gc, False,
												circ[0] - circ[2], circ[1] - circ[2],
												circ[2] * 2, circ[2] * 2,
												0, 64 * 360)


if __name__ == '__main__':
	TagMap()
	gtk.main()
