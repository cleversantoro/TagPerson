#!/usr/bin/python
#-*- coding:utf-8 -*-

class Site:
	CIRCLE = 0
	POLYGON = 1
	
	PLACE = 0
	CITY = 1
	KINGDOM = 2
	REGION = 3
	FOREST = 4
	MOUNTAIN = 5
	WATER = 6
	ISLAND = 7
		
	def __init__(self, name=None, type=PLACE, areaType=CIRCLE):
		self.type = type
		self.name = name
		self.image = None
		self.quote = None
		self.description = None
		self.areaType = areaType
		self.area = None

	def set_area(self, areaType, area):
		self.areaType = areaType
		self.area = area

class City (Site):
	def __init__(self, name=None, capital=False):
		Site.__init__(self, name, Site.CITY)
		self.capital = capital
		
class Kingdom (Site):
	def __init__(self, name=None):
		Site.__init__(self, name, Site.KINGDOM, Site.POLYGON)
		self.cities = []

if __name__ == '__main__':
	k = Kingdom('Calco')
	k.description = 'Reino em algum lugar de Tagmar.'
	print k.name
	print k.description
