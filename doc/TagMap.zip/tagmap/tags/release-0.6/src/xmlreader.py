#!/usr/bin/python
#-*- coding:utf-8 -*-

from data import Site
from data import City
from data import Kingdom
import xml.dom.minidom as minidom

def load_atlas(filename='atlas.xml'):
	doc = minidom.parse(filename)
	
	sites = {}

	mapfile = doc.childNodes[0].getAttribute('imagem')
	scale = float(doc.childNodes[0].getAttribute('escala'))

	center_node = doc.childNodes[0].getElementsByTagName('marcozero')[0]
	center = (int(center_node.getAttribute('x')),
					int(center_node.getAttribute('y')))

	for site_node in doc.childNodes[0].childNodes[2:]:
		if site_node.nodeType == site_node.ELEMENT_NODE:
			site = process_site(site_node)
			sites[site.name] = site

	return (mapfile, center, scale, sites)

def process_site(node):
	if node.nodeName == 'reino':
		site = Kingdom(node.getAttribute('nome').encode('utf-8'))
		cities_nodes = node.getElementsByTagName('cidades')
		if cities_nodes:
			for city in cities_nodes[0].childNodes:
				if city.nodeType == city.ELEMENT_NODE:
					site.cities.append(process_site(city))
	elif node.nodeName == 'cidade':
		capital = node.getAttribute('tipo')
		site = City(node.getAttribute('nome').encode('utf-8'), capital=='capital')
	else:
		if node.nodeName == 'regiao':
			type = Site.REGION
		elif node.nodeName == 'floresta':
			type = Site.FOREST
		elif node.nodeName == 'montanha':
			type = Site.MOUNTAIN
		elif node.nodeName == 'agua':
			type = Site.WATER
		elif node.nodeName == 'ilha':
			type = Site.ISLAND
		else:
			type = Site.PLACE
		site = Site(node.getAttribute('nome').encode('utf-8'), type)

	image = node.getAttribute('imagem')
	if image:
		site.image = image

	quote = node.getElementsByTagName('citacao')
	if quote:
		quote = quote[0]
		site.quote = (quote.childNodes[0].nodeValue.encode('utf-8').strip(),
								quote.getAttribute('autor').encode('utf-8'))

	node_descr = node.getElementsByTagName('descricao')
	if node_descr:
		site.description = node_descr[0].\
									childNodes[0].nodeValue.encode('utf-8').strip()

	site.areaType, site.area = \
							process_area(node.getElementsByTagName('area')[-1])

	return site							

def process_place(site):
	if site.nodeName == 'cidade':
		region = City(site.getAttribute('nome').encode('utf-8'))
		capital = site.getAttribute('tipo')
		region.capital = (capital == 'capital')
	else:
		region = Site(site.getAttribute('nome').encode('utf-8'))

def process_area(node):
	if node:
		tipo = node.getAttribute('tipo')
		if tipo == 'circulo':
			areaType = Site.CIRCLE
			coord = node.getElementsByTagName('coordenadas')[0]
			coords = (int(coord.getAttribute('x')),
							int(coord.getAttribute('y')),
							int(coord.getAttribute('raio')))
		elif tipo == 'ponto':
			areaType = Site.CIRCLE
			coord = node.getElementsByTagName('coordenadas')[0]
			coords = (int(coord.getAttribute('x')), int(coord.getAttribute('y')), 4)
		else:
			areaType = Site.POLYGON
			coords = []
			for coord in node.getElementsByTagName('coordenadas'):
				coords.append((int(coord.getAttribute('x')),
									int(coord.getAttribute('y'))))
			coords.append(coords[0])
			coords = tuple(coords)

	return (areaType, coords)

if __name__ == '__main__':
	sites = load_atlas('data/atlas.xml')
	
	print sites

	'''	
	for name in sites.keys():
		site = sites[name]

		print site.name
		print site.image
		print site.description
		if type(site) == type(Kingdom):
			print site.quote
			print site.cities
		print site.areaType
		print site.area
		print '\n'
		
	print sites.keys()
	'''
