import sys

name = 'tagmap'
version = '0.7.6'
if sys.platform.startswith('win'):
	doc_dir = ''
	data_dir = 'data'
	glade_dir = 'glade'
else:
	doc_dir = '@prefix@/share/doc/' + name
	data_dir = '@prefix@/share/' + name + '/data'
	glade_dir = '@prefix@/share/' + name + '/glade'
